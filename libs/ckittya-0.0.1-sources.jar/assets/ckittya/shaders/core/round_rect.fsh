#version 150

layout(std140) uniform u {
    vec4  u_Rect;
    vec4  u_Radii;
    vec4  u_colorRect;
    vec4  u_colorRect2;
    vec4  u_colorShadow;
    vec2  u_gradientDirectionVector;
    float u_edgeSoftness;
    float u_shadowSoftness;
};

in vec2 f_Position;

out vec4 fragColor;

float sdRoundBox(vec2 p, vec2 b, vec4 r) {
    r.xy = (p.x > 0.0) ? r.xy : r.zw;
    r.x  = (p.y > 0.0) ? r.x  : r.y;

    vec2 q = abs(p) - b + r.x;
    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r.x;
}

void main() {
    vec2 p = f_Position - u_Rect.xy;
    vec2 halfSize = u_Rect.zw * 0.5;

    vec4 radii = vec4(u_Radii.y, u_Radii.x, u_Radii.w, u_Radii.z);

    float dist = sdRoundBox(p, halfSize, radii);

    float aa = max(u_edgeSoftness, fwidth(dist));
    float shapeAlpha = 1.0 - smoothstep(0.0, aa, dist);

    vec4 fill = u_colorRect;
    if (any(notEqual(u_colorRect2, u_colorRect)) && length(u_gradientDirectionVector) > 0.0001) {
        vec2 dir = normalize(u_gradientDirectionVector);
        float proj = dot(p / max(halfSize, vec2(0.0001)), dir);
        float t = clamp(proj * 0.5 + 0.5, 0.0, 1.0);
        fill = mix(u_colorRect, u_colorRect2, t);
    }

    vec4 result = vec4(0.0);
    if (u_shadowSoftness > 0.0 && u_colorShadow.a > 0.0) {
        float shadowDist = dist;
        float shadowAlpha = 1.0 - smoothstep(-u_shadowSoftness, u_shadowSoftness, shadowDist);
        vec4 shadow = vec4(u_colorShadow.rgb, u_colorShadow.a * shadowAlpha);
        result = shadow;
    }

    vec4 fillColor = vec4(fill.rgb, fill.a * shapeAlpha);
    result = mix(result, fillColor, fillColor.a);

    fragColor = result;
}
