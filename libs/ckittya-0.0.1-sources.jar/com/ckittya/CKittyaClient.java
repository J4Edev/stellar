package com.ckittya;

import com.ckittya.easter.EasterInit;
import com.ckittya.render.CKRenderer;
import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CKittyaClient implements ClientModInitializer {

    public static final String MOD_ID = "ckittya";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("[CKittya]: Meow!");
        CKRenderer.init();
        EasterInit.init();
    }
}
