package com.ckittya.easter;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

public class EarTextureGenerator {

    public static final Identifier EAR_TEXTURE_ID =
            Identifier.fromNamespaceAndPath("ckittya", "dynamic/cat_ears");

    private static final int WHITE = 0xFFFFFFFF;
    private static final int PINK  = 0xFFCC88FF;
    private static final int TRANS = 0x00000000;

    public static void register() {
        NativeImage img = new NativeImage(NativeImage.Format.RGBA, 32, 16, false);

        for (int x = 0; x < 32; x++)
            for (int y = 0; y < 16; y++)
                img.setPixel(x, y, TRANS);

        paintEar(img, 0);
        paintEar(img, 16);

        DynamicTexture dynTex = new DynamicTexture(() -> "ckittya:cat_ears", img);
        Minecraft.getInstance().getTextureManager().register(EAR_TEXTURE_ID, dynTex);
    }

    private static void paintEar(NativeImage img, int x) {
        for (int dx = 0; dx < 4; dx++) {
            for (int dy = 0; dy < 4; dy++) {
                boolean sideBorder = dx == 0 || dx == 3 || dy == 3;
                img.setPixel(x + 1 + dx, 1 + dy, sideBorder ? WHITE : PINK);
            }
        }

        fillRect(img, x + 1, 0, 4, 1, WHITE);
        fillRect(img, x + 5, 0, 4, 1, WHITE);
        fillRect(img, x + 0, 1, 1, 4, WHITE);
        fillRect(img, x + 5, 1, 1, 4, WHITE);
        fillRect(img, x + 6, 1, 4, 4, WHITE);

        img.setPixel(x + 1, 8, WHITE);
        img.setPixel(x + 2, 8, WHITE);
        img.setPixel(x + 0, 9, WHITE);
        img.setPixel(x + 1, 9, WHITE);
        img.setPixel(x + 2, 9, WHITE);
        img.setPixel(x + 3, 9, WHITE);
    }

    private static void fillRect(NativeImage img, int x, int y, int w, int h, int color) {
        for (int dx = 0; dx < w; dx++)
            for (int dy = 0; dy < h; dy++)
                img.setPixel(x + dx, y + dy, color);
    }
}