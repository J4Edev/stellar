package com.ckittya.easter;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.Identifier;

public class EasterInit {

    public static final ModelLayerLocation EAR_LAYER =
            new ModelLayerLocation(
                    Identifier.fromNamespaceAndPath("ckittya", "cat_ears"),
                    "main"
            );

    public static void init() {
        ModelLayerRegistry.registerModelLayer(EAR_LAYER, EarModel::createLayer);

        ClientLifecycleEvents.CLIENT_STARTED.register(client ->
                EarTextureGenerator.register()
        );
    }
}
