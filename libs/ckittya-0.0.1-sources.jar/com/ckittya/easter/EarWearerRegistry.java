package com.ckittya.easter;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;

import java.util.Set;

public class EarWearerRegistry {

    private static final Set<String> EAR_WEARERS = Set.of(
            "MikaSukie",
            "catkisser5592950",
            "meowical",
            "catfarting"
    );

    public static boolean hasEars(AvatarRenderState state) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getConnection() == null) return false;

        for (String username : EAR_WEARERS) {
            PlayerInfo info = mc.getConnection().getPlayerInfoIgnoreCase(username);
            if (info == null) continue;

            if (info.getSkin().body().texturePath()
                    .equals(state.skin.body().texturePath())) {
                return true;
            }
        }

        return false;
    }
}
