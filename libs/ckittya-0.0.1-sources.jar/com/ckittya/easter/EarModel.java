package com.ckittya.easter;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;

public class EarModel extends EntityModel<AvatarRenderState> {

    private final ModelPart head;

    public EarModel(ModelPart root) {
        super(root);
        this.head = root.getChild("head");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition head = root.addOrReplaceChild("head",
                CubeListBuilder.create(),
                PartPose.offset(0f, 0f, 0f)
        );

        PartDefinition leftEar = head.addOrReplaceChild("left_ear",
                CubeListBuilder.create()
                        .texOffs(0, 0)
                        .addBox(-2f, -4f, -0.5f, 4, 4, 1),
                PartPose.offset(-4f, -8f, 0f)
        );
        leftEar.addOrReplaceChild("left_ear_tip",
                CubeListBuilder.create()
                        .texOffs(0, 8)
                        .addBox(-0.5f, -1f, -0.5f, 1, 1, 1),
                PartPose.offset(0f, -4f, 0f)
        );

        PartDefinition rightEar = head.addOrReplaceChild("right_ear",
                CubeListBuilder.create()
                        .texOffs(16, 0)
                        .addBox(-2f, -4f, -0.5f, 4, 4, 1),
                PartPose.offset(4f, -8f, 0f)
        );
        rightEar.addOrReplaceChild("right_ear_tip",
                CubeListBuilder.create()
                        .texOffs(16, 8)
                        .addBox(-0.5f, -1f, -0.5f, 1, 1, 1),
                PartPose.offset(0f, -4f, 0f)
        );

        return LayerDefinition.create(mesh, 32, 16);
    }

    @Override
    public void setupAnim(AvatarRenderState state) {
        head.yRot = state.yRot  * ((float) Math.PI / 180f);
        head.xRot = state.xRot * ((float) Math.PI / 180f);

        float wiggle = (float) Math.sin(state.ageInTicks * 0.05f) * 0.08f;
        head.getChild("left_ear").zRot  =  wiggle;
        head.getChild("right_ear").zRot = -wiggle;
    }
}