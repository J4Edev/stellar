package com.ckittya.easter;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.rendertype.RenderTypes;

import java.util.Set;
import java.util.UUID;

public class CatEarLayer extends RenderLayer<AvatarRenderState, PlayerModel> {

    private static final Set<UUID> EAR_WEARERS = Set.of(
            UUID.fromString("118b6f55-ece6-4fc1-a287-cac593998918"),
            UUID.fromString("dadc0e19-31e5-4543-ab9e-119a7a7da1ee"),
            UUID.fromString("f234289c-6a7a-4b23-a222-c2402ad2c60e"),
            UUID.fromString("e246eacd-df96-4ca2-974e-46d51e35d38a")
            );

    private final EarModel model;

    public CatEarLayer(RenderLayerParent<AvatarRenderState, PlayerModel> renderer,
                       net.minecraft.client.model.geom.EntityModelSet modelSet) {
        super(renderer);
        this.model = new EarModel(modelSet.bakeLayer(EasterInit.EAR_LAYER));
    }

    @Override
    public void submit(PoseStack poseStack,
                       SubmitNodeCollector submitNodeCollector,
                       int lightCoords,
                       AvatarRenderState state,
                       float yRot,
                       float xRot) {

        if (state.isInvisible) return;
        if (!EarWearerRegistry.hasEars(state)) return;

        int overlayCoords = LivingEntityRenderer.getOverlayCoords(state, 0.0F);
        submitNodeCollector.submitModel(
                this.model,
                state,
                poseStack,
                RenderTypes.entityCutout(EarTextureGenerator.EAR_TEXTURE_ID),
                lightCoords,
                overlayCoords,
                state.outlineColor,
                null
        );
    }
}
