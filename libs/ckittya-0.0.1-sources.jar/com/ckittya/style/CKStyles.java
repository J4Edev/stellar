package com.ckittya.style;

public final class CKStyles {
    private CKStyles() {}

    private static CKTheme theme = new CKTheme();

    public static CKTheme theme() {
        return theme;
    }

    public static void setTheme(CKTheme newTheme) {
        theme = newTheme;
    }
}