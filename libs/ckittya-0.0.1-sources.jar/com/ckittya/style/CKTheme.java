package com.ckittya.style;

import com.ckittya.util.CKColor;

public final class CKTheme {
    public int screenBg = CKColor.CK_BG;
    public int panelBg = CKColor.CK_SURFACE;
    public int panelBorder = CKColor.CK_BORDER;
    public float panelRadius = 8f;

    public int buttonBg = CKColor.CK_SURFACE;
    public int buttonHover = CKColor.CK_ACCENT;
    public int buttonPress = CKColor.CK_ACCENT_DIM;
    public int buttonText = CKColor.CK_TEXT;
    public float buttonRadius = 6f;
    public float buttonHoverSpeed = 18f;
    public float buttonPressSpeed = 20f;

    public int sliderTrack = CKColor.of(255, 45, 38, 65);
    public int sliderFill = CKColor.CK_ACCENT;
    public int sliderThumb = CKColor.WHITE;
    public int sliderText = CKColor.CK_TEXT_DIM;
    public float sliderTrackHeight = 4f;
    public float sliderThumbRadius = 7f;
    public float sliderHoverSpeed = 10f;

    public int textBoxBg = CKColor.CK_SURFACE;
    public int textBoxBgFocused = CKColor.CK_SURFACE;
    public int textBoxBorder = CKColor.CK_BORDER;
    public int textBoxBorderFocused = CKColor.CK_ACCENT;
    public float textBoxRadius = 6f;
    public float textBoxPadX = 6f;

    public int selectionIndicator = CKColor.CK_ACCENT_DIM;
    public int selectionBorder = CKColor.CK_ACCENT;
    public float selectionRadius = 8f;
    public float selectionSpeed = 6f;

    public int scrollTrack = CKColor.of(80, 45, 38, 65);
    public int scrollThumb = CKColor.CK_ACCENT_DIM;
    public int scrollThumbHover = CKColor.CK_ACCENT;
    public float scrollBarWidth = 4f;
    public float scrollSpeed = 16f;
    public float scrollWheelStep = 24f;

    public int textColor = CKColor.CK_TEXT;
    public int placeholderColor = CKColor.CK_TEXT_DIM;
    public int selectionColor = CKColor.withAlphaF(CKColor.CK_ACCENT, 0.4f);
}