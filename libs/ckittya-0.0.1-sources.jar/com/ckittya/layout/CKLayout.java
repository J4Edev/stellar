package com.ckittya.layout;

import com.ckittya.util.Rect;
import java.util.List;

public final class CKLayout {

    private CKLayout() {}

    public enum Axis { ROW, COLUMN }

    public enum Align {
        START,
        CENTER,
        END,
        STRETCH
    }

    public static final class LayoutConfig {

        public float prefWidth  = -1;
        public float prefHeight = -1;

        public float minWidth  = 0;
        public float minHeight = 0;

        public float growX = 0;
        public float growY = 0;

        public float marginTop = 0, marginBottom = 0, marginLeft = 0, marginRight = 0;

        public Align alignSelf = null;

        public LayoutConfig size(float w, float h)           { prefWidth = w; prefHeight = h; return this; }
        public LayoutConfig width(float w)                   { prefWidth = w;  return this; }
        public LayoutConfig height(float h)                  { prefHeight = h; return this; }
        public LayoutConfig grow(float x, float y)           { growX = x; growY = y; return this; }
        public LayoutConfig growX(float x)                   { this.growX = x; return this; }
        public LayoutConfig growY(float y)                   { this.growY = y; return this; }
        public LayoutConfig fillWidth()                      { growX = 1; prefWidth = -1; return this; }
        public LayoutConfig fillHeight()                     { growY = 1; prefHeight = -1; return this; }
        public LayoutConfig margin(float all)                { return margin(all, all, all, all); }
        public LayoutConfig margin(float v, float h)         { return margin(v, h, v, h); }
        public LayoutConfig margin(float t, float r, float b, float l) {
            marginTop = t; marginRight = r; marginBottom = b; marginLeft = l; return this;
        }
        public LayoutConfig alignSelf(Align a)               { alignSelf = a; return this; }
    }

    public static final class ContainerConfig {
        public Axis  axis     = Axis.COLUMN;
        public Align align    = Align.START;
        public Align justify  = Align.START;
        public float gap      = 4;
        public float padTop   = 0, padBottom = 0, padLeft = 0, padRight = 0;

        public ContainerConfig axis(Axis a)     { axis = a; return this; }
        public ContainerConfig align(Align a)   { align = a; return this; }
        public ContainerConfig gap(float g)     { gap = g; return this; }
        public ContainerConfig pad(float all)   { return pad(all, all, all, all); }
        public ContainerConfig pad(float v, float h) { return pad(v, h, v, h); }
        public ContainerConfig justify(Align a) { justify = a; return this; }
        public ContainerConfig pad(float t, float r, float b, float l) {
            padTop = t; padRight = r; padBottom = b; padLeft = l; return this;
        }
    }

    public interface CKWidget {
        LayoutConfig layoutConfig();
        void setBounds(Rect bounds);
        Rect getBounds();
    }

    public static void layout(ContainerConfig cfg, Rect container, List<? extends CKWidget> children) {
        if (children.isEmpty()) return;

        boolean isRow = cfg.axis == Axis.ROW;

        float availMain  = isRow
                ? container.w() - cfg.padLeft - cfg.padRight
                : container.h() - cfg.padTop  - cfg.padBottom;
        float availCross = isRow
                ? container.h() - cfg.padTop - cfg.padBottom
                : container.w() - cfg.padLeft - cfg.padRight;

        float fixedTotal = 0;
        float totalGrow  = 0;
        int   gaps       = children.size() - 1;

        float[] mainSizes  = new float[children.size()];
        float[] crossSizes = new float[children.size()];

        for (int i = 0; i < children.size(); i++) {
            var lc = children.get(i).layoutConfig();
            float margin = isRow
                    ? lc.marginLeft + lc.marginRight
                    : lc.marginTop  + lc.marginBottom;

            float grow = isRow ? lc.growX : lc.growY;
            totalGrow += grow;

            if (grow == 0) {
                float pref = isRow ? lc.prefWidth : lc.prefHeight;
                float size = pref >= 0 ? pref : (isRow ? lc.minWidth : lc.minHeight);
                mainSizes[i] = size + margin;
                fixedTotal  += mainSizes[i];
            }

            float crossPref = isRow ? lc.prefHeight : lc.prefWidth;
            float crossMargin = isRow
                    ? lc.marginTop + lc.marginBottom
                    : lc.marginLeft + lc.marginRight;
            crossSizes[i] = crossPref >= 0 ? crossPref : (availCross - crossMargin);
        }

        float remaining = availMain - fixedTotal - gaps * cfg.gap;
        for (int i = 0; i < children.size(); i++) {
            var lc = children.get(i).layoutConfig();
            float grow = isRow ? lc.growX : lc.growY;
            if (grow > 0 && totalGrow > 0) {
                float margin = isRow
                        ? lc.marginLeft + lc.marginRight
                        : lc.marginTop  + lc.marginBottom;
                mainSizes[i] = (remaining * (grow / totalGrow)) + margin;
            }
        }

        float occupiedMain = 0f;
        for (float s : mainSizes) occupiedMain += s;
        occupiedMain += gaps * cfg.gap;

        float leftoverMain = Math.max(0f, availMain - occupiedMain);

        float mainStart = switch (cfg.justify) {
            case CENTER -> leftoverMain / 2f;
            case END -> leftoverMain;
            default -> 0f;
        };

        float cursor = (isRow ? container.x() + cfg.padLeft : container.y() + cfg.padTop) + mainStart;

        float crossOrigin = isRow
                ? container.y() + cfg.padTop
                : container.x() + cfg.padLeft;

        for (int i = 0; i < children.size(); i++) {
            var lc = children.get(i).layoutConfig();
            float margin = isRow
                    ? lc.marginLeft + lc.marginRight
                    : lc.marginTop  + lc.marginBottom;

            float innerMain  = mainSizes[i] - margin;
            float innerCross = crossSizes[i];

            float mainMarginBefore  = isRow ? lc.marginLeft  : lc.marginTop;
            float crossMarginBefore = isRow ? lc.marginTop   : lc.marginLeft;
            float crossMargin       = isRow ? lc.marginTop + lc.marginBottom : lc.marginLeft + lc.marginRight;

            Align align = lc.alignSelf != null ? lc.alignSelf : cfg.align;
            float crossPos;
            float actualCross;
            switch (align) {
                case CENTER  -> { crossPos = crossOrigin + crossMarginBefore + (availCross - crossMargin - innerCross) / 2f; actualCross = innerCross; }
                case END     -> { crossPos = crossOrigin + availCross - crossMargin - innerCross; actualCross = innerCross; }
                case STRETCH -> { crossPos = crossOrigin + crossMarginBefore; actualCross = availCross - crossMargin; }
                default      -> { crossPos = crossOrigin + crossMarginBefore; actualCross = innerCross; }
            }

            float rx = isRow ? cursor + mainMarginBefore : crossPos;
            float ry = isRow ? crossPos : cursor + mainMarginBefore;
            float rw = isRow ? innerMain : actualCross;
            float rh = isRow ? actualCross : innerMain;

            children.get(i).setBounds(new Rect(rx, ry, rw, rh));

            cursor += mainSizes[i] + cfg.gap;
        }
    }
}
