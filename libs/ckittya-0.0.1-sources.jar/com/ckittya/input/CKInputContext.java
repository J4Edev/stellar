package com.ckittya.input;

public final class CKInputContext {

    public double mouseX, mouseY;
    public boolean mousePressed;
    public boolean mouseReleased;
    public boolean mouseDown;
    public boolean rightPressed;
    public double scrollDelta;
    public int keyPressed = -1;
    public int keyMods;
    public char charTyped;

    public boolean isShift() { return (keyMods & 1) != 0; }
    public boolean isCtrl()  { return (keyMods & 2) != 0; }
    public boolean isAlt()   { return (keyMods & 4) != 0; }

    public boolean isHovered(com.ckittya.util.Rect r) {
        return r.contains(mouseX, mouseY);
    }
    public boolean isClicked(com.ckittya.util.Rect r) {
        return mousePressed && r.contains(mouseX, mouseY);
    }
    public boolean isReleased(com.ckittya.util.Rect r) {
        return mouseReleased && r.contains(mouseX, mouseY);
    }

    public void resetFrameEvents() {
        mousePressed  = false;
        mouseReleased = false;
        rightPressed  = false;
        keyPressed    = -1;
        keyMods       = 0;
        charTyped     = 0;
        scrollDelta   = 0;
    }
}
