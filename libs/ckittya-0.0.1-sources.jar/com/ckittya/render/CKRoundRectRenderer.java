package com.ckittya.render;

import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.fabricmc.fabric.api.client.rendering.v1.PictureInPictureRendererRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.pip.PictureInPictureRenderer;
import net.minecraft.client.renderer.DynamicUniformStorage;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.state.gui.pip.PictureInPictureRenderState;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;
import java.util.OptionalDouble;

public class CKRoundRectRenderer extends PictureInPictureRenderer<CKRoundRectRenderer.@NotNull State> {

    private State lastState;

    public static void init() {
        PictureInPictureRendererRegistry.register(context -> new CKRoundRectRenderer());
    }

    protected CKRoundRectRenderer() {
    }

    @Override
    public @NonNull Class<State> getRenderStateClass() {
        return State.class;
    }

    @Override
    protected boolean textureIsReadyToBlit(State state) {
        return Objects.equals(lastState, state);
    }

    @Override
    protected void renderToTexture(State state, @NonNull PoseStack poseStack, SubmitNodeCollector submitNodeCollector) {
        float width = (state.extentX + 2 * State.OUTSET) * state.scale;
        float height = (state.extentY + 2 * State.OUTSET) * state.scale;

        BufferBuilder builder = new BufferBuilder(
                new ByteBufferBuilder(DefaultVertexFormat.POSITION.getVertexSize() * 4),
                PrimitiveTopology.QUADS,
                DefaultVertexFormat.POSITION
        );
        {
            float textureWidth = width + state.subpixelX * state.scale;
            float textureHeight = height + state.subpixelY * state.scale;
            builder.addVertex(0F, 0F, 0F);
            builder.addVertex(0F, textureHeight, 0F);
            builder.addVertex(textureWidth, textureHeight, 0F);
            builder.addVertex(textureWidth, 0F, 0F);
        }
        MeshData mesh = builder.buildOrThrow();

        GpuBufferSlice dynamicTransformsBuffer = RenderSystem.getDynamicUniforms().writeTransform(
                RenderSystem.getModelViewMatrixCopy(),
                new Vector4f(),
                new Vector3f(),
                new Matrix4f()
        );

        GpuBufferSlice myUniformBuffer = Uniform.STORAGE.writeUniform(buffer -> {
            Std140Builder.intoBuffer(buffer)
                    .putVec4(
                            state.subpixelX * state.scale + width * 0.5F,
                            state.subpixelY * state.scale + height * 0.5F,
                            state.extentX * state.scale,
                            state.extentY * state.scale)
                    .putVec4(
                            state.radiusRB * state.scale,
                            state.radiusRT * state.scale,
                            state.radiusLB * state.scale,
                            state.radiusLT * state.scale)
                    .putVec4(state.color)
                    .putVec4(state.color2 == null ? state.color : state.color2)
                    .putVec4(state.shadowColor)
                    .putVec2(state.gradientDirectionX, state.gradientDirectionY)
                    .putFloat(state.edgeSoftness * state.scale)
                    .putFloat(state.shadow * state.scale);
        });

        GpuBuffer vertexGpuBuffer = RenderSystem.getDevice().createBuffer(
                () -> "CKittya Rounded Rectangle vertices", GpuBuffer.USAGE_VERTEX, mesh.vertexBuffer());
        GpuBufferSlice vertexBuffer = vertexGpuBuffer.slice();
        RenderSystem.AutoStorageIndexBuffer indexStorage =
                RenderSystem.getSequentialBuffer(mesh.drawState().primitiveTopology());
        GpuBuffer indexBuffer = indexStorage.getBuffer(mesh.drawState().indexCount());

        try (
                mesh;
                RenderPass pass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(
                        () -> "CKittya Rounded Rectangle",
                        RenderSystem.outputColorTextureOverride,
                        Optional.empty(),
                        RenderSystem.outputDepthTextureOverride,
                        OptionalDouble.empty()
                )
        ) {
            pass.setPipeline(CKRenderPipelines.PIPELINE_ROUND_RECT);
            RenderSystem.bindDefaultUniforms(pass);
            pass.setUniform("DynamicTransforms", dynamicTransformsBuffer);
            pass.setUniform("u", myUniformBuffer);
            pass.setVertexBuffer(0, vertexBuffer);
            pass.setIndexBuffer(indexBuffer, indexStorage.type());
            pass.drawIndexed(mesh.drawState().indexCount(), 1, 0, 0, 0);
        }

        vertexGpuBuffer.close();
        lastState = state;
    }

    @Override
    protected @NonNull String getTextureLabel() {
        return "CKittya Rounded Rectangle PIP";
    }

    public static final class State implements PictureInPictureRenderState {

        public static final float OUTSET = 14F;

        public transient final float left, top, right, bottom;

        public final float scale;
        public final float shadow;
        public final Vector4f color;
        public final Vector4f shadowColor;
        public @Nullable Vector4f color2;

        public float radiusLT, radiusRT, radiusLB, radiusRB;
        public float gradientDirectionX = 0F, gradientDirectionY = 0F;
        public float edgeSoftness = 1F;

        private final float subpixelX, subpixelY;
        private final float extentX, extentY;
        private transient final ScreenRectangle scissorArea;
        private transient final ScreenRectangle bounds;

        public State(GuiGraphicsExtractor context, float left, float top, float right, float bottom,
                     float radius, float shadow, int color, int shadowColor) {
            if (!Float.isFinite(radius) || radius < 0.0f) {
                radius = 0;
            }

            this.left = left;
            this.top = top;
            this.right = right;
            this.bottom = bottom;
            this.subpixelX = left - Mth.floor(left);
            this.subpixelY = top - Mth.floor(top);
            this.scale = Minecraft.getInstance().getWindow().getGuiScale();
            this.shadow = shadow;
            this.color = new Vector4f(ARGB.red(color) / 255F, ARGB.green(color) / 255F, ARGB.blue(color) / 255F, ARGB.alpha(color) / 255F);
            this.shadowColor = new Vector4f(ARGB.red(shadowColor) / 255F, ARGB.green(shadowColor) / 255F, ARGB.blue(shadowColor) / 255F, ARGB.alpha(shadowColor) / 255F);

            this.extentX = right - left;
            this.extentY = bottom - top;
            this.radiusLT = this.radiusRT = this.radiusLB = this.radiusRB = Math.min(radius, Math.min(extentX, extentY) * 0.5F);
            this.scissorArea = context.scissorStack.peek();
            ScreenRectangle b = new ScreenRectangle(this.x0(), this.y0(), this.x1() - this.x0(), this.y1() - this.y0());
            this.bounds = scissorArea == null ? b : scissorArea.intersection(b);
        }

        public State setGradientColor(int color) {
            this.color2 = new Vector4f(ARGB.red(color) / 255F, ARGB.green(color) / 255F, ARGB.blue(color) / 255F, ARGB.alpha(color) / 255F);
            return this;
        }

        public State setGradientDirection(float x, float y) {
            this.gradientDirectionX = x;
            this.gradientDirectionY = y;
            return this;
        }

        public State setEdgeSoftness(float edgeSoftness) {
            this.edgeSoftness = edgeSoftness;
            return this;
        }

        public State setRadii(float lt, float rt, float lb, float rb) {
            float maxR = Math.min(extentX, extentY) * 0.5F;
            this.radiusLT = Math.min(lt, maxR);
            this.radiusRT = Math.min(rt, maxR);
            this.radiusLB = Math.min(lb, maxR);
            this.radiusRB = Math.min(rb, maxR);
            return this;
        }

        @Override
        public int x0() {
            return Mth.floor(left) - (int) OUTSET;
        }

        @Override
        public int x1() {
            return Mth.ceil(right + OUTSET);
        }

        @Override
        public int y0() {
            return Mth.floor(top) - (int) OUTSET;
        }

        @Override
        public int y1() {
            return Mth.ceil(bottom + OUTSET);
        }

        @Override
        public float scale() {
            return 1F;
        }

        @Override
        public @Nullable ScreenRectangle scissorArea() {
            return scissorArea;
        }

        @Override
        public @Nullable ScreenRectangle bounds() {
            return bounds;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof State s)) return false;
            return Float.compare(scale, s.scale) == 0
                    && Float.compare(shadow, s.shadow) == 0
                    && Float.compare(extentX, s.extentX) == 0
                    && Float.compare(extentY, s.extentY) == 0
                    && Float.compare(subpixelX, s.subpixelX) == 0
                    && Float.compare(subpixelY, s.subpixelY) == 0
                    && Float.compare(radiusLT, s.radiusLT) == 0
                    && Float.compare(radiusRT, s.radiusRT) == 0
                    && Float.compare(radiusLB, s.radiusLB) == 0
                    && Float.compare(radiusRB, s.radiusRB) == 0
                    && Float.compare(gradientDirectionX, s.gradientDirectionX) == 0
                    && Float.compare(gradientDirectionY, s.gradientDirectionY) == 0
                    && Float.compare(edgeSoftness, s.edgeSoftness) == 0
                    && color.equals(s.color)
                    && shadowColor.equals(s.shadowColor)
                    && Objects.equals(color2, s.color2);
        }

        @Override
        public int hashCode() {
            int h = Float.hashCode(scale);
            h = 31 * h + Float.hashCode(shadow);
            h = 31 * h + Float.hashCode(extentX);
            h = 31 * h + Float.hashCode(extentY);
            h = 31 * h + Float.hashCode(subpixelX);
            h = 31 * h + Float.hashCode(subpixelY);
            h = 31 * h + Float.hashCode(radiusLT);
            h = 31 * h + Float.hashCode(radiusRT);
            h = 31 * h + Float.hashCode(radiusLB);
            h = 31 * h + Float.hashCode(radiusRB);
            h = 31 * h + Float.hashCode(gradientDirectionX);
            h = 31 * h + Float.hashCode(gradientDirectionY);
            h = 31 * h + Float.hashCode(edgeSoftness);
            h = 31 * h + color.hashCode();
            h = 31 * h + shadowColor.hashCode();
            h = 31 * h + Objects.hashCode(color2);
            return h;
        }
    }

    public static class Uniform {
        private static final int SIZE = new Std140SizeCalculator()
                .putVec4()
                .putVec4()
                .putVec4()
                .putVec4()
                .putVec4()
                .putVec2()
                .putFloat()
                .putFloat()
                .get();

        private static final DynamicUniformStorage<DynamicUniformStorage.@NotNull DynamicUniform> STORAGE =
                new DynamicUniformStorage<>("CKittya Rounded Rectangle UBO", SIZE, 4);

        public static void clear() {
            STORAGE.endFrame();
        }
    }
}