package com.ckittya.render;

import com.ckittya.util.CKColor;
import com.ckittya.util.Rect;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

import java.util.ArrayDeque;
import java.util.Deque;

public final class CKRenderer {
    private static final CKRenderer INSTANCE = new CKRenderer();
    public static CKRenderer get() { return INSTANCE; }

    private static final int NO_SHADOW = 0x00000000;

    private GuiGraphicsExtractor ctx;
    private Font font;

    private final Deque<Rect> scissorStack = new ArrayDeque<>();

    public static void init() {
        CKRoundRectRenderer.init();
    }

    public void begin(GuiGraphicsExtractor context, int w, int h) {
        this.ctx  = context;
        this.font = Minecraft.getInstance().font;
        scissorStack.clear();
    }

    public void end() {
        CKRoundRectRenderer.Uniform.clear();
    }

    public void pushScissor(Rect r) {
        Rect clipped = scissorStack.isEmpty() ? r : r.clampTo(scissorStack.peek());
        scissorStack.push(clipped);
        ctx.enableScissor((int) clipped.x(), (int) clipped.y(),
                (int) clipped.x2(), (int) clipped.y2());
    }

    public void popScissor() {
        if (!scissorStack.isEmpty()) scissorStack.pop();
        if (scissorStack.isEmpty()) {
            ctx.disableScissor();
        } else {
            Rect c = scissorStack.peek();
            ctx.disableScissor();
            ctx.enableScissor((int) c.x(), (int) c.y(), (int) c.x2(), (int) c.y2());
        }
    }

    public void rect(Rect r, int color) {
        ctx.fill((int) r.x(), (int) r.y(), (int) r.x2(), (int) r.y2(), color);
    }

    public void rectGradientV(Rect r, int colorTop, int colorBottom) {
        ctx.fillGradient((int) r.x(), (int) r.y(), (int) r.x2(), (int) r.y2(),
                colorTop, colorBottom);
    }

    public void rectOutline(Rect r, int color) {
        rect(new Rect(r.x(),       r.y(),       r.w(),     1),         color);
        rect(new Rect(r.x(),       r.y2() - 1f, r.w(),     1),         color);
        rect(new Rect(r.x(),       r.y() + 1f,  1,         r.h() - 2), color);
        rect(new Rect(r.x2() - 1f, r.y() + 1f,  1,         r.h() - 2), color);
    }

    public void roundRect(Rect r, float radius, int color) {
        roundRect(r, radius, color, 0f, NO_SHADOW);
    }

    public void roundRect(Rect r, float radius, int color, float shadow, int shadowColor) {
        if (r.w() <= 0 || r.h() <= 0) return;
        CKRoundRectRenderer.State state = new CKRoundRectRenderer.State(
                ctx, r.x(), r.y(), r.x2(), r.y2(),
                radius, shadow, color, shadowColor);
        ctx.guiRenderState.addPicturesInPictureState(state);
    }

    public void roundRectGradient(Rect r, float radius,
                                  int color, int color2,
                                  float dirX, float dirY,
                                  float shadow, int shadowColor) {
        if (r.w() <= 0 || r.h() <= 0) return;
        CKRoundRectRenderer.State state = new CKRoundRectRenderer.State(
                ctx, r.x(), r.y(), r.x2(), r.y2(),
                radius, shadow, color, shadowColor);
        state.setGradientColor(color2).setGradientDirection(dirX, dirY);
        ctx.guiRenderState.addPicturesInPictureState(state);
    }

    public void roundRectEx(Rect r,
                            float radiusLT, float radiusRT,
                            float radiusLB, float radiusRB,
                            int color, float shadow, int shadowColor) {
        if (r.w() <= 0 || r.h() <= 0) return;
        float minR = Math.min(r.w(), r.h()) * 0.5F;
        CKRoundRectRenderer.State state = new CKRoundRectRenderer.State(
                ctx, r.x(), r.y(), r.x2(), r.y2(),
                0f, shadow, color, shadowColor);
        state.setRadii(
                Math.min(radiusLT, minR),
                Math.min(radiusRT, minR),
                Math.min(radiusLB, minR),
                Math.min(radiusRB, minR));
        ctx.guiRenderState.addPicturesInPictureState(state);
    }

    public void texture(Identifier id, Rect dest, int u, int v,
                        int regionW, int regionH, int texW, int texH) {
        texture(id, dest, u, v, regionW, regionH, texW, texH, CKColor.WHITE);
    }

    public void texture(Identifier id, Rect dest) {
        int w = (int) dest.w(), h = (int) dest.h();
        texture(id, dest, 0, 0, w, h, w, h, CKColor.WHITE);
    }

    public void texture(Identifier id, Rect dest, int u, int v,
                        int regionW, int regionH, int texW, int texH, int tint) {
        ctx.blit(
                RenderPipelines.GUI_TEXTURED_PREMULTIPLIED_ALPHA,
                id,
                (int) dest.x(), (int) dest.y(),
                u, v,
                (int) dest.w(), (int) dest.h(),
                regionW, regionH,
                texW, texH,
                tint);
    }

    public void texture(Identifier id, Rect dest, int tint) {
        int w = (int) dest.w(), h = (int) dest.h();
        texture(id, dest, 0, 0, w, h, w, h, tint);
    }

    public void text(String str, float x, float y, int color) {
        ctx.text(font, str, (int) x, (int) y, CKColor.hex(color), false);
    }

    public void textShadow(String str, float x, float y, int color) {
        ctx.text(font, str, (int) x, (int) y, CKColor.hex(color), true);
    }

    public void textCentredX(String str, Rect r, float y, int color) {
        int w = font.width(str);
        text(str, r.x() + (r.w() - w) / 2f, y, color);
    }

    public void textCentred(String str, Rect r, int color) {
        int   w  = font.width(str);
        float tx = r.x() + (r.w() - w) / 2f;
        float ty = r.y() + (r.h() - font.lineHeight) / 2f;
        text(str, tx, ty, color);
    }

    public void textTruncated(String str, float x, float y, int maxWidth, int color) {
        if (textWidth(str) <= maxWidth) { text(str, x, y, color); return; }
        String ellipsis = "...";
        if (textWidth(ellipsis) > maxWidth) { text("", x, y, color); return; }
        String t = str;
        while (!t.isEmpty() && textWidth(t + ellipsis) > maxWidth)
            t = t.substring(0, t.length() - 1);
        text(t + ellipsis, x, y, color);
    }

    public int textWidth(String s) { return font.width(s); }
    public int fontHeight()        { return font.lineHeight; }
}