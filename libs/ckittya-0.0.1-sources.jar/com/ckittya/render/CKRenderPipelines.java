package com.ckittya.render;

import com.mojang.blaze3d.PrimitiveTopology;
import com.mojang.blaze3d.pipeline.BindGroupLayout;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.ColorTargetState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.shaders.UniformType;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import net.minecraft.client.renderer.BindGroupLayouts;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

public class CKRenderPipelines {
    public static final BindGroupLayout ROUND_RECT_UNIFORM = BindGroupLayout.builder()
            .withUniform("u", UniformType.UNIFORM_BUFFER)
            .build();

    public static final RenderPipeline PIPELINE_ROUND_RECT = RenderPipelines.register(
            RenderPipeline.builder()
                    .withLocation(Identifier.fromNamespaceAndPath("ckittya", "pipeline/round_rect"))
                    .withFragmentShader(Identifier.fromNamespaceAndPath("ckittya", "core/round_rect"))
                    .withVertexShader(Identifier.fromNamespaceAndPath("ckittya", "core/round_rect"))
                    .withBindGroupLayout(BindGroupLayouts.GLOBALS)
                    .withBindGroupLayout(BindGroupLayouts.MATRICES_PROJECTION)
                    .withBindGroupLayout(ROUND_RECT_UNIFORM)
                    .withColorTargetState(new ColorTargetState(BlendFunction.TRANSLUCENT))
                    .withVertexBinding(0, DefaultVertexFormat.POSITION)
                    .withPrimitiveTopology(PrimitiveTopology.QUADS)
                    .build()
    );
}