package com.ckittya.widgets;

import com.ckittya.render.CKRenderer;
import com.ckittya.util.CKColor;
import com.ckittya.util.Rect;

public class CKDivider extends CKWidget {

    private int   color      = CKColor.CK_BORDER;
    private boolean vertical = false;
    private float thickness  = 1f;

    public CKDivider() {
        layoutConfig().size(-1, thickness).fillWidth();
    }

    public CKDivider color(int c)   { this.color = c; return this; }
    public CKDivider vertical()     { this.vertical = true; layoutConfig().size(thickness, -1).fillHeight(); return this; }
    public CKDivider thickness(float t) { this.thickness = t; return this; }

    @Override
    public void draw(CKRenderer r) {
        r.rect(getBounds(), color);
    }
}
