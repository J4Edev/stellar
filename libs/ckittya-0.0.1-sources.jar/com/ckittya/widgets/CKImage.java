package com.ckittya.widgets;

import com.ckittya.render.CKRenderer;
import com.ckittya.util.Rect;
import net.minecraft.resources.Identifier;

public class CKImage extends CKWidget {

    private Identifier texture;
    private int u, v, regionW, regionH, texW, texH;
    private boolean fullTexture;
    private int tint = com.ckittya.util.CKColor.WHITE;

    public CKImage(Identifier texture) {
        this.texture     = texture;
        this.fullTexture = true;
    }

    public CKImage(Identifier texture, int u, int v, int regionW, int regionH, int texW, int texH) {
        this.texture  = texture;
        this.u        = u;
        this.v        = v;
        this.regionW  = regionW;
        this.regionH  = regionH;
        this.texW     = texW;
        this.texH     = texH;
        this.fullTexture = false;
        layoutConfig().size(regionW, regionH);
    }

    public CKImage texture(Identifier t) { this.texture = t; return this; }

    public CKImage tint(int argb) { this.tint = argb; return this; }

    public CKImage opacity(float a) {
        this.tint = com.ckittya.util.CKColor.withAlphaF(tint, a);
        return this;
    }

    @Override
    public void draw(CKRenderer r) {
        Rect b = getBounds();
        if (fullTexture) {
            r.texture(texture, b, tint);
        } else {
            r.texture(texture, b, u, v, regionW, regionH, texW, texH, tint);
        }
    }
}
