package com.ckittya.widgets;

import com.ckittya.anim.CKAnimation;
import com.ckittya.input.CKInputContext;
import com.ckittya.layout.CKLayout;
import com.ckittya.render.CKRenderer;
import com.ckittya.style.CKStyles;
import com.ckittya.util.CKColor;
import com.ckittya.util.Rect;

import java.util.function.Consumer;

public class CKScrollView extends CKContainer {

    private float offset        = 0f;
    private float targetOffset  = 0f;
    private float lastAppliedOffset = 0f;
    private float contentSize   = 0f;
    private boolean animate     = true;

    private boolean draggingThumb = false;
    private float dragGrabOffset  = 0f;

    private float hoverT = 0f;

    private int trackColor      = CKStyles.theme().scrollTrack;
    private int thumbColor      = CKStyles.theme().scrollThumb;
    private int thumbHoverColor = CKStyles.theme().scrollThumbHover;
    private float barWidth      = CKStyles.theme().scrollBarWidth;
    private float scrollSpeed   = CKStyles.theme().scrollSpeed;
    private float wheelStep     = CKStyles.theme().scrollWheelStep;

    private boolean showTrack = true;

    private Consumer<Float> onScroll = null;

    private Rect cachedThumb = Rect.ZERO;

    public CKScrollView() {
        clip(true);
    }

    public CKScrollView trackColor(int c)      { this.trackColor = c; return this; }
    public CKScrollView thumbColor(int c)      { this.thumbColor = c; return this; }
    public CKScrollView thumbHoverColor(int c) { this.thumbHoverColor = c; return this; }
    public CKScrollView barWidth(float w)      { this.barWidth = w; return this; }
    public CKScrollView showTrack(boolean b)   { this.showTrack = b; return this; }
    public CKScrollView scrollSpeed(float s)   { this.scrollSpeed = s; return this; }
    public CKScrollView wheelStep(float s)     { this.wheelStep = s; return this; }

    public CKScrollView animate(boolean a) { this.animate = a; return this; }

    public CKScrollView onScroll(Consumer<Float> cb) { this.onScroll = cb; return this; }

    @Override
    public CKScrollView container(java.util.function.Consumer<CKLayout.ContainerConfig> fn) {
        super.container(fn);
        return this;
    }

    @Override
    public CKScrollView add(CKWidget widget) {
        super.add(widget);
        return this;
    }

    @Override
    public CKScrollView remove(CKWidget widget) {
        super.remove(widget);
        return this;
    }

    public float getOffset() { return offset; }

    public CKScrollView setOffset(float o) { return setOffset(o, animate); }

    public CKScrollView setOffset(float o, boolean animated) {
        targetOffset = clampOffset(o);
        if (!animated) offset = targetOffset;
        fireOnScroll();
        return this;
    }

    public CKScrollView scrollBy(float delta) { return scrollBy(delta, animate); }

    public CKScrollView scrollBy(float delta, boolean animated) {
        return setOffset(targetOffset + delta, animated);
    }

    public CKScrollView scrollTo(float o) { return setOffset(o); }

    public CKScrollView scrollToTop()    { return setOffset(0f); }
    public CKScrollView scrollToEnd()    { return setOffset(maxOffset()); }

    public float maxOffset() {
        return Math.max(0f, contentSize - getBounds().h());
    }

    public float scrollPercent() {
        float max = maxOffset();
        return max <= 0f ? 0f : CKAnimation.clamp01(targetOffset / max);
    }

    public CKScrollView scrollToPercent(float pct) {
        return setOffset(maxOffset() * CKAnimation.clamp01(pct));
    }

    public boolean isScrollable() { return maxOffset() > 0.01f; }

    private float clampOffset(float o) {
        return Math.max(0f, Math.min(o, maxOffset()));
    }

    private void fireOnScroll() {
        if (onScroll != null) onScroll.accept(targetOffset);
    }

    @Override
    public void layoutChildren() {
        if (children().isEmpty()) { contentSize = 0f; return; }

        Rect b = getBounds();
        boolean isRow = containerCfg.axis == CKLayout.Axis.ROW;

        Rect virtual = isRow
                ? new Rect(b.x(), b.y(), Math.max(b.w(), 100000f), b.h())
                : new Rect(b.x(), b.y(), b.w(), Math.max(b.h(), 100000f));

        CKLayout.layout(containerCfg, virtual, children());

        float measured = 0f;
        for (CKWidget child : children()) {
            float edge = isRow ? child.getBounds().x2() : child.getBounds().y2();
            float origin = isRow ? virtual.x() : virtual.y();
            measured = Math.max(measured, edge - origin);
        }
        contentSize = measured;

        targetOffset = clampOffset(targetOffset);
        if (!animate) offset = targetOffset;

        float shift = -offset;
        for (CKWidget child : children()) {
            Rect cb = child.getBounds();
            child.setBounds(isRow ? cb.translate(shift, 0f) : cb.translate(0f, shift));
        }
        lastAppliedOffset = offset;

        for (CKWidget child : children()) {
            if (child instanceof CKContainer c) c.layoutChildren();
            if (child instanceof CKSelectionStrip s) s.layoutChildren();
        }
    }

    @Override
    public void update(CKInputContext input, float deltaTicks) {
        float dt = Math.max(0f, deltaTicks);

        if (animate) {
            offset = CKAnimation.approach(offset, targetOffset, scrollSpeed, dt / 20f);
            if (Math.abs(offset - targetOffset) < 0.05f) offset = targetOffset;
        } else {
            offset = targetOffset;
        }

        boolean overBar = isScrollable() && cachedThumb.h() > 0
                && new Rect(cachedThumb.x() - 2f, getBounds().y(), barWidth + 4f, getBounds().h())
                .contains(input.mouseX, input.mouseY);
        hoverT = CKAnimation.approach(hoverT, (draggingThumb || overBar) ? 1f : 0f, 14f, dt / 20f);

        applyOffsetToChildren();

        super.update(input, deltaTicks);
    }

    private void applyOffsetToChildren() {
        float delta = offset - lastAppliedOffset;
        if (Math.abs(delta) < 0.0001f) return;
        boolean isRow = containerCfg.axis == CKLayout.Axis.ROW;
        for (CKWidget child : children()) {
            Rect cb = child.getBounds();
            child.setBounds(isRow ? cb.translate(-delta, 0f) : cb.translate(0f, -delta));
        }
        lastAppliedOffset = offset;
    }

    @Override
    public void handleInput(CKInputContext input) {
        Rect b = getBounds();
        boolean hoveredView = b.contains(input.mouseX, input.mouseY);

        if (hoveredView && input.scrollDelta != 0) {
            scrollBy((float) -input.scrollDelta * wheelStep);
        }

        if (showTrack && isScrollable()) {
            Rect thumbHit = new Rect(cachedThumb.x() - 2f, cachedThumb.y(), barWidth + 4f, cachedThumb.h());
            if (input.isClicked(thumbHit)) {
                draggingThumb = true;
                dragGrabOffset = (float) input.mouseY - cachedThumb.y();
            } else if (input.mousePressed && new Rect(cachedThumb.x() - 2f, b.y(), barWidth + 4f, b.h()).contains(input.mouseX, input.mouseY)) {
                float trackY = b.y();
                float trackH = Math.max(1f, b.h() - cachedThumb.h());
                float t = CKAnimation.clamp01(((float) input.mouseY - trackY - cachedThumb.h() / 2f) / trackH);
                setOffset(t * maxOffset());
                draggingThumb = true;
                dragGrabOffset = cachedThumb.h() / 2f;
            }

            if (draggingThumb && input.mouseReleased) draggingThumb = false;

            if (draggingThumb) {
                float trackH = Math.max(1f, b.h() - cachedThumb.h());
                float t = CKAnimation.clamp01(((float) input.mouseY - dragGrabOffset - b.y()) / trackH);
                setOffset(t * maxOffset(), false);
            }
        }

        super.handleInput(input);
    }

    @Override
    public void draw(CKRenderer r) {
        Rect b = getBounds();
        r.pushScissor(b);
        for (CKWidget child : children()) {
            if (child.isVisible()) child.draw(r);
        }
        r.popScissor();

        if (showTrack && isScrollable()) {
            float trackX = b.x2() - barWidth - 2f;
            Rect trackRect = new Rect(trackX, b.y(), barWidth, b.h());
            r.roundRect(trackRect, barWidth / 2f, trackColor);

            float visibleRatio = CKAnimation.clamp01(b.h() / contentSize);
            float thumbH = Math.max(10f, b.h() * visibleRatio);
            float thumbY = b.y() + scrollPercent() * (b.h() - thumbH);
            cachedThumb = new Rect(trackX, thumbY, barWidth, thumbH);

            int color = CKColor.lerp(thumbColor, thumbHoverColor, hoverT);
            r.roundRect(cachedThumb, barWidth / 2f, color);
        } else {
            cachedThumb = Rect.ZERO;
        }
    }
}