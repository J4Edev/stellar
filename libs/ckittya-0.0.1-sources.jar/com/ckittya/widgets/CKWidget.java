package com.ckittya.widgets;

import com.ckittya.anim.CKAnimatable;
import com.ckittya.input.CKInputContext;
import com.ckittya.layout.CKLayout;
import com.ckittya.render.CKRenderer;
import com.ckittya.util.Rect;

public abstract class CKWidget implements CKLayout.CKWidget, CKAnimatable {

    private Rect bounds = Rect.ZERO;
    private final CKLayout.LayoutConfig layoutConfig = new CKLayout.LayoutConfig();

    @Override public Rect getBounds()                      { return bounds; }
    @Override public void setBounds(Rect r)                { this.bounds = r; }
    @Override public CKLayout.LayoutConfig layoutConfig()  { return layoutConfig; }

    private boolean visible = true;
    private boolean enabled = true;

    public boolean isVisible() { return visible; }
    public boolean isEnabled() { return enabled; }

    public CKWidget setVisible(boolean v) { this.visible = v; return this; }
    public CKWidget setEnabled(boolean e) { this.enabled = e; return this; }

    private String tooltip = null;
    public CKWidget setTooltip(String t) { this.tooltip = t; return this; }
    public String getTooltip()           { return tooltip; }

    public abstract void draw(CKRenderer r);
    public void handleInput(CKInputContext input) {}
    public void onClose() {}
    @Override public void update(CKInputContext input, float deltaTicks) {}

    protected boolean hovered(CKInputContext input) {
        return input.isHovered(bounds);
    }

    protected float x()  { return bounds.x(); }
    protected float y()  { return bounds.y(); }
    protected float w()  { return bounds.w(); }
    protected float h()  { return bounds.h(); }
    protected float cx() { return bounds.x() + bounds.w() / 2f; }
    protected float cy() { return bounds.y() + bounds.h() / 2f; }
}
