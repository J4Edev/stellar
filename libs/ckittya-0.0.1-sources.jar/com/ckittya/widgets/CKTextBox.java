package com.ckittya.widgets;

import com.ckittya.input.CKInputContext;
import com.ckittya.render.CKRenderer;
import com.ckittya.style.CKStyles;
import com.ckittya.util.CKColor;
import com.ckittya.util.Rect;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

import java.util.function.Consumer;
import java.util.function.Predicate;

public class CKTextBox extends CKWidget {

    private String            placeholder      = "";
    private int               maxLength        = 256;
    private Predicate<String> filter           = s -> true;
    private Consumer<String>  onChange         = null;
    private Consumer<String>  onSubmit         = null;

    private int   bgColor         = CKStyles.theme().textBoxBg;
    private int   bgFocused       = CKStyles.theme().textBoxBgFocused;
    private int   borderColor     = CKStyles.theme().textBoxBorder;
    private int   borderFocused   = CKStyles.theme().textBoxBorderFocused;
    private int   textColor       = CKStyles.theme().textColor;
    private int   placeholderColor = CKStyles.theme().placeholderColor;
    private int   selectionColor  = CKStyles.theme().selectionColor;
    private float radius          = CKStyles.theme().textBoxRadius;
    private float padX            = CKStyles.theme().textBoxPadX;

    private StringBuilder text           = new StringBuilder();
    private int           cursor         = 0;
    private int           selectionStart = -1;
    private boolean       focused        = false;
    private int           scrollOffsetPx = 0;

    public CKTextBox() {
        layoutConfig().fillWidth().height(20);
    }

    public CKTextBox placeholder(String p)        { this.placeholder = p; return this; }
    public CKTextBox maxLength(int m)             { this.maxLength = m; return this; }
    public CKTextBox filter(Predicate<String> f)  { this.filter = f; return this; }
    public CKTextBox onChange(Consumer<String> c) { this.onChange = c; return this; }
    public CKTextBox onSubmit(Consumer<String> c) { this.onSubmit = c; return this; }
    public CKTextBox bg(int c)                    { this.bgColor = c; return this; }
    public CKTextBox textColor(int c)             { this.textColor = c; return this; }
    public CKTextBox radius(float r)              { this.radius = r; return this; }
    public CKTextBox bgFocused(int c)       { this.bgFocused = c; return this; }
    public CKTextBox border(int c)          { this.borderColor = c; return this; }
    public CKTextBox borderFocused(int c)   { this.borderFocused = c; return this; }
    public CKTextBox placeholderColor(int c) { this.placeholderColor = c; return this; }
    public CKTextBox selectionColor(int c)  { this.selectionColor = c; return this; }
    public CKTextBox padX(float p)          { this.padX = p; return this; }

    public String  getText()         { return text.toString(); }
    public boolean isFocused()       { return focused; }

    public void setText(String t) {
        text = new StringBuilder(t);
        cursor = t.length();
        clearSelection();
        notifyChange();
    }

    @Override
    public void draw(CKRenderer r) {
        int bg     = focused ? bgFocused    : bgColor;
        int border = focused ? borderFocused : borderColor;

        Rect b = getBounds();

        if (CKColor.alpha(border) > 0) {
            r.roundRect(b, radius, border);
            r.roundRect(b.inset(1f), Math.max(0f, radius - 1f), bg);
        } else {
            r.roundRect(b, radius, bg);
        }

        r.pushScissor(b.inset(1));

        float textX = x() + padX - scrollOffsetPx;
        float textY = y() + (h() - r.fontHeight()) / 2f;

        if (text.isEmpty() && !focused) {
            r.text(placeholder, textX, textY, placeholderColor);
        } else {
            String str = text.toString();

            if (focused && hasSelection()) {
                int   selA = Math.min(cursor, selectionStart);
                int   selB = Math.max(cursor, selectionStart);
                float selX = textX + r.textWidth(str.substring(0, selA));
                float selW = r.textWidth(str.substring(selA, selB));
                r.rect(new Rect(selX, textY, selW, r.fontHeight()), selectionColor);
            }

            r.text(str, textX, textY, textColor);

            if (focused) {
                long now = System.currentTimeMillis();
                if ((now / 530) % 2 == 0) {
                    float cx = textX + r.textWidth(str.substring(0, cursor));
                    r.rect(new Rect(cx, textY, 1, r.fontHeight()), CKColor.CK_TEXT);
                }
            }
        }

        r.popScissor();
    }

    @Override
    public void update(CKInputContext input, float deltaTicks) {
        int available = Math.max(0, (int) w() - (int) padX * 2 - 2);
        String prefix = text.substring(0, Math.min(cursor, text.length()));
        int cursorPx = Minecraft.getInstance().font.width(prefix);

        int leftGuard = cursorPx - scrollOffsetPx;
        if (leftGuard > available - 6) {
            scrollOffsetPx = cursorPx - available + 6;
        } else if (leftGuard < 0) {
            scrollOffsetPx = cursorPx;
        }
        scrollOffsetPx = Math.max(0, scrollOffsetPx);
    }

    @Override
    public void handleInput(CKInputContext input) {
        if (input.mousePressed) {
            boolean wasF = focused;
            focused = input.isHovered(getBounds());
            if (focused && !wasF) {
                cursor = text.length();
                clearSelection();
            }
            if (!focused) {
                clearSelection();
            }
        }

        if (!focused) return;

        if (input.charTyped != 0) insertChar(input.charTyped);
        if (input.keyPressed != -1) handleKey(input.keyPressed, input.keyMods);
    }

    private void handleKey(int key, int mods) {
        boolean ctrl  = (mods & GLFW.GLFW_MOD_CONTROL) != 0;
        boolean shift = (mods & GLFW.GLFW_MOD_SHIFT)   != 0;

        switch (key) {
            case GLFW.GLFW_KEY_LEFT -> {
                if (ctrl) cursor = wordLeft();
                else      cursor = Math.max(0, cursor - 1);
                if (!shift) clearSelection(); else startOrExtendSelection();
            }
            case GLFW.GLFW_KEY_RIGHT -> {
                if (ctrl) cursor = wordRight();
                else      cursor = Math.min(text.length(), cursor + 1);
                if (!shift) clearSelection(); else startOrExtendSelection();
            }
            case GLFW.GLFW_KEY_HOME -> {
                cursor = 0;
                if (!shift) clearSelection(); else startOrExtendSelection();
            }
            case GLFW.GLFW_KEY_END -> {
                cursor = text.length();
                if (!shift) clearSelection(); else startOrExtendSelection();
            }
            case GLFW.GLFW_KEY_BACKSPACE -> {
                if (hasSelection())       deleteSelection();
                else if (ctrl)            deleteWordLeft();
                else if (cursor > 0) {
                    text.deleteCharAt(cursor - 1);
                    cursor--;
                    notifyChange();
                }
            }
            case GLFW.GLFW_KEY_DELETE -> {
                if (hasSelection())                    deleteSelection();
                else if (cursor < text.length()) {
                    text.deleteCharAt(cursor);
                    notifyChange();
                }
            }
            case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> {
                if (onSubmit != null) onSubmit.accept(text.toString());
                focused = false;
            }
            case GLFW.GLFW_KEY_ESCAPE -> {
                focused = false;
                clearSelection();
            }
            case GLFW.GLFW_KEY_A -> { if (ctrl) { selectionStart = 0; cursor = text.length(); } }
            case GLFW.GLFW_KEY_C -> { if (ctrl && hasSelection()) copyToClipboard(); }
            case GLFW.GLFW_KEY_X -> { if (ctrl && hasSelection()) { copyToClipboard(); deleteSelection(); } }
            case GLFW.GLFW_KEY_V -> { if (ctrl) pasteFromClipboard(); }
        }
    }

    private void insertChar(char c) {
        if (hasSelection()) deleteSelection();
        if (text.length() >= maxLength) return;
        String candidate = text.substring(0, cursor) + c + text.substring(cursor);
        if (filter.test(candidate)) {
            text.insert(cursor, c);
            cursor++;
            notifyChange();
        }
    }

    private void insertString(String s) {
        for (char c : s.toCharArray()) insertChar(c);
    }

    private void deleteSelection() {
        int a = Math.min(cursor, selectionStart);
        int b = Math.max(cursor, selectionStart);
        text.delete(a, b);
        cursor = a;
        clearSelection();
        notifyChange();
    }

    private void deleteWordLeft() {
        int target = wordLeft();
        text.delete(target, cursor);
        cursor = target;
        notifyChange();
    }

    private boolean hasSelection() { return selectionStart >= 0 && selectionStart != cursor; }
    private void clearSelection()  { selectionStart = -1; }

    private void startOrExtendSelection() {
        if (selectionStart == -1) selectionStart = cursor;
    }

    private int wordLeft() {
        int i = cursor - 1;
        while (i > 0 && text.charAt(i - 1) == ' ') i--;
        while (i > 0 && text.charAt(i - 1) != ' ') i--;
        return i;
    }

    private int wordRight() {
        int i = cursor;
        while (i < text.length() && text.charAt(i) == ' ') i++;
        while (i < text.length() && text.charAt(i) != ' ') i++;
        return i;
    }

    public void setMaxLength(int maxLength) {
        this.maxLength = maxLength;
    }

    private void copyToClipboard() {
        int a = Math.min(cursor, selectionStart);
        int b = Math.max(cursor, selectionStart);
        Minecraft.getInstance().keyboardHandler.setClipboard(text.substring(a, b));
    }

    private void pasteFromClipboard() {
        String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
        if (clip != null && !clip.isEmpty()) insertString(clip);
    }

    private void notifyChange() {
        if (onChange != null) onChange.accept(text.toString());
    }

    @Override
    public void onClose() {
        focused = false;
    }
}
