package com.ckittya.widgets;

import com.ckittya.render.CKRenderer;

public class CKSpacer extends CKWidget {

    public CKSpacer() {}

    public CKSpacer fillMain() {
        layoutConfig().grow(1, 1);
        return this;
    }

    public CKSpacer size(float w, float h) {
        layoutConfig().size(w, h);
        return this;
    }

    @Override
    public void draw(CKRenderer r) {
    }
}
