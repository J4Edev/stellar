package com.ckittya.widgets;

import com.ckittya.render.CKRenderer;
import com.ckittya.util.CKColor;

import java.util.function.Supplier;

public class CKLabel extends CKWidget {

    public enum Align { LEFT, CENTER, RIGHT }

    private String            text     = "";
    private Supplier<String>  supplier = null;
    private int               color    = CKColor.CK_TEXT;
    private boolean           shadow   = false;
    private Align             align    = Align.LEFT;

    public CKLabel(String text) {
        this.text = text;
        layoutConfig().height(12);
    }

    public CKLabel text(String t)     { this.text = t; this.supplier = null; return this; }

    public CKLabel live(Supplier<String> s) { this.supplier = s; return this; }

    public CKLabel color(int c)       { this.color = c; return this; }
    public CKLabel shadow(boolean s)  { this.shadow = s; return this; }
    public CKLabel align(Align a)     { this.align = a; return this; }
    public CKLabel dim()              { return color(CKColor.CK_TEXT_DIM); }

    public String getText() {
        return supplier != null ? supplier.get() : text;
    }

    @Override
    public void draw(CKRenderer r) {
        String current = getText();
        float ty  = y() + (h() - r.fontHeight()) / 2f;
        int   maxW = (int) w();

        switch (align) {
            case LEFT -> {
                if (shadow) r.textShadow(truncate(r, current, maxW), x(), ty, color);
                else        r.textTruncated(current, x(), ty, maxW, color);
            }
            case CENTER -> r.textCentred(truncate(r, current, maxW), getBounds(), color);
            case RIGHT  -> {
                String s  = truncate(r, current, maxW);
                int    tw = r.textWidth(s);
                float  tx = x() + w() - tw;
                if (shadow) r.textShadow(s, tx, ty, color);
                else        r.text(s, tx, ty, color);
            }
        }
    }

    private String truncate(CKRenderer r, String s, int maxW) {
        if (r.textWidth(s) <= maxW) return s;
        String t = r.textWidth("...") > maxW ? "" : s;
        while (!t.isEmpty() && r.textWidth(t + "...") > maxW) {
            t = t.substring(0, t.length() - 1);
        }
        return t + (s.length() > t.length() ? "..." : "");
    }
}
