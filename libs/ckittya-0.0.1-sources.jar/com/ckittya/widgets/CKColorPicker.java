package com.ckittya.widgets;

import com.ckittya.anim.CKAnimation;
import com.ckittya.input.CKInputContext;
import com.ckittya.render.CKRenderer;
import com.ckittya.util.CKColor;
import com.ckittya.util.Rect;

import java.util.function.Consumer;

public class CKColorPicker extends CKWidget {

    private float hue;
    private float saturation;
    private float alpha;

    private Consumer<Integer> onChange = null;

    private float displaySat;
    private float displayAlpha;

    private float hoverSat   = 0f;
    private float hoverAlpha = 0f;
    private float hoverHue   = 0f;

    private static final float SNAP_SPEED  = 18f;
    private static final float HOVER_SPEED = 10f;

    private boolean draggingHue   = false;
    private boolean draggingSat   = false;
    private boolean draggingAlpha = false;

    private static final float HUE_H    = 12f;
    private static final float SLIDER_H = 16f;
    private static final float SWATCH_H = 16f;
    private static final float GAP      = 5f;
    private static final float RADIUS   = 3f;
    private static final float TRACK_H  = 4f;
    private static final float THUMB_R  = 5.5f;

    private final CKTextBox hexInput;
    private boolean ignoreHexChange = false;

    private static float totalH() {
        return HUE_H + GAP + SLIDER_H + GAP + SLIDER_H + GAP + SWATCH_H;
    }

    private float cachedHueX, cachedHueW;
    private float cachedSatX,   cachedSatW;
    private float cachedAlphaX, cachedAlphaW;
    private float cachedSliderY_sat, cachedSliderY_alpha;

    public CKColorPicker(float hue, float saturation, float alpha) {
        this.hue          = clamp01(hue);
        this.saturation   = clamp01(saturation);
        this.alpha        = clamp01(alpha);
        this.displaySat   = this.saturation;
        this.displayAlpha = this.alpha;
        layoutConfig().fillWidth().height(totalH());

        hexInput = new CKTextBox()
                .placeholder("#AARRGGBB")
                .maxLength(9)
                .filter(s -> s.matches("#?[0-9A-Fa-f]{0,8}"))
                .onChange(this::onHexChanged)
                .onSubmit(this::onHexChanged);
        hexInput.layoutConfig().height(SWATCH_H);
        syncHexInput();
    }

    public static CKColorPicker fromColor(int argb) {
        float[] hsv = rgbToHsv(CKColor.redF(argb), CKColor.greenF(argb), CKColor.blueF(argb));
        return new CKColorPicker(hsv[0], hsv[1], CKColor.alphaF(argb));
    }

    public CKColorPicker onChange(Consumer<Integer> c) { this.onChange = c; return this; }

    public float getHue()        { return hue; }
    public float getSaturation() { return saturation; }
    public float getAlpha()      { return alpha; }

    public int getColor() { return hsvToArgb(hue, saturation, 1f, alpha); }

    public void setHue(float h) {
        hue = clamp01(h);
        syncHexInput();
        fireChange();
    }

    public void setSaturation(float s) {
        saturation = clamp01(s);
        syncHexInput();
        fireChange();
    }

    public void setAlpha(float a) {
        alpha = clamp01(a);
        syncHexInput();
        fireChange();
    }

    private void fireChange() {
        if (onChange != null) onChange.accept(getColor());
    }

    private void syncHexInput() {
        if (hexInput != null && !hexInput.isFocused()) {
            ignoreHexChange = true;
            hexInput.setText(String.format("#%08X", getColor()));
            ignoreHexChange = false;
        }
    }

    private void onHexChanged(String raw) {
        if (ignoreHexChange) return;
        String s = raw.startsWith("#") ? raw.substring(1) : raw;
        if (s.length() != 8 && s.length() != 6) return;
        try {
            int argb;
            if (s.length() == 6) {
                int rgb = Integer.parseUnsignedInt(s, 16);
                argb = 0xFF000000 | rgb;
            } else {
                argb = (int) Long.parseUnsignedLong(s, 16);
            }
            float[] hsv = rgbToHsv(CKColor.redF(argb), CKColor.greenF(argb), CKColor.blueF(argb));
            ignoreHexChange = true;
            hue        = clamp01(hsv[0]);
            saturation = clamp01(hsv[1]);
            alpha      = CKColor.alphaF(argb);
            ignoreHexChange = false;
            fireChange();
        } catch (NumberFormatException ignored) {
        }
    }

    @Override
    public void update(CKInputContext input, float deltaTicks) {
        float dt = Math.max(0f, deltaTicks) / 20f;

        boolean overHue   = cachedHueW   > 0 && new Rect(cachedHueX,   y(),                  cachedHueW,   HUE_H   ).contains(input.mouseX, input.mouseY);
        boolean overSat   = cachedSatW   > 0 && new Rect(cachedSatX,   cachedSliderY_sat,     cachedSatW,   SLIDER_H).contains(input.mouseX, input.mouseY);
        boolean overAlpha = cachedAlphaW > 0 && new Rect(cachedAlphaX, cachedSliderY_alpha,   cachedAlphaW, SLIDER_H).contains(input.mouseX, input.mouseY);

        hoverHue   = CKAnimation.approach(hoverHue,   (draggingHue   || overHue)   ? 1f : 0f, HOVER_SPEED, dt);
        hoverSat   = CKAnimation.approach(hoverSat,   (draggingSat   || overSat)   ? 1f : 0f, HOVER_SPEED, dt);
        hoverAlpha = CKAnimation.approach(hoverAlpha, (draggingAlpha || overAlpha) ? 1f : 0f, HOVER_SPEED, dt);

        if (draggingSat) {
            displaySat = saturation;
        } else {
            displaySat = CKAnimation.approach(displaySat, saturation, SNAP_SPEED, dt);
            if (Math.abs(displaySat - saturation) < 0.001f) displaySat = saturation;
        }

        if (draggingAlpha) {
            displayAlpha = alpha;
        } else {
            displayAlpha = CKAnimation.approach(displayAlpha, alpha, SNAP_SPEED, dt);
            if (Math.abs(displayAlpha - alpha) < 0.001f) displayAlpha = alpha;
        }

        hexInput.update(input, deltaTicks);
    }

    @Override
    public void draw(CKRenderer r) {
        float bx = x(), by = y(), bw = w();

        cachedHueX = bx;
        cachedHueW = bw;
        Rect hueBar = new Rect(bx, by, bw, HUE_H);

        drawHueBar(r, hueBar);

        float hueThumbX = bx + hue * bw;
        float expand = 1f + hoverHue * 0.3f;
        r.roundRect(new Rect(hueThumbX - 2f * expand, by - 1f, 4f * expand, HUE_H + 2f),
                2f, CKColor.WHITE);
        r.roundRect(new Rect(hueThumbX - 1f * expand, by,      2f * expand, HUE_H),
                1f, CKColor.BLACK);

        float satY      = by + HUE_H + GAP;
        cachedSliderY_sat = satY;

        String satVal   = String.format("%.0f%%", saturation * 100f);
        float  satValW  = r.textWidth(satVal) + 6f;
        cachedSatX = bx;
        cachedSatW = bw - satValW;

        int huePure = hsvToArgb(hue, 1f, 1f, 1f);
        int hueGrey = hsvToArgb(hue, 0f, 1f, 1f);
        drawColorSlider(r,
                bx, satY, cachedSatW, SLIDER_H,
                hueGrey, huePure,
                displaySat, saturation, hoverSat);

        r.text(satVal,
                bx + cachedSatW + 3f,
                satY + (SLIDER_H - r.fontHeight()) / 2f,
                CKColor.CK_TEXT_DIM);

        float alphaY     = satY + SLIDER_H + GAP;
        cachedSliderY_alpha = alphaY;

        String alphaVal  = String.format("%.0f%%", alpha * 100f);
        float  alphaValW = r.textWidth(alphaVal) + 6f;
        cachedAlphaX = bx;
        cachedAlphaW = bw - alphaValW;

        int opaqueColor = hsvToArgb(hue, saturation, 1f, 1f);
        int clearColor  = CKColor.withAlpha(opaqueColor, 0);
        drawCheckerboard(r, new Rect(bx, alphaY + (SLIDER_H - TRACK_H) / 2f,
                cachedAlphaW, TRACK_H), RADIUS);
        drawColorSlider(r,
                bx, alphaY, cachedAlphaW, SLIDER_H,
                clearColor, opaqueColor,
                displayAlpha, alpha, hoverAlpha);

        r.text(alphaVal,
                bx + cachedAlphaW + 3f,
                alphaY + (SLIDER_H - r.fontHeight()) / 2f,
                CKColor.CK_TEXT_DIM);

        float swatchY   = alphaY + SLIDER_H + GAP;
        int   finalColor = getColor();

        r.roundRect(new Rect(bx, swatchY, SWATCH_H, SWATCH_H), RADIUS,
                CKColor.of(255, 100, 100, 100));
        r.roundRect(new Rect(bx, swatchY, SWATCH_H, SWATCH_H), RADIUS, finalColor);
        r.roundRect(new Rect(bx, swatchY, SWATCH_H, SWATCH_H), RADIUS,
                CKColor.withAlpha(CKColor.CK_BORDER, 120));

        float hexX = bx + SWATCH_H + 4f;
        float hexW = bw - SWATCH_H - 4f;
        hexInput.setBounds(new Rect(hexX, swatchY, hexW, SWATCH_H));
        hexInput.draw(r);
    }

    @Override
    public void handleInput(CKInputContext input) {
        float by = y();

        Rect hueRect = new Rect(cachedHueX, by, cachedHueW, HUE_H);
        if (input.isClicked(hueRect)) { draggingHue = true; applyHueMouse(input.mouseX); }
        if (draggingHue && input.mouseReleased) draggingHue = false;
        if (draggingHue) applyHueMouse(input.mouseX);

        Rect satRect = new Rect(cachedSatX, cachedSliderY_sat, cachedSatW, SLIDER_H);
        if (input.isClicked(satRect)) { draggingSat = true; applySatMouse(input.mouseX); }
        if (draggingSat && input.mouseReleased) draggingSat = false;
        if (draggingSat) applySatMouse(input.mouseX);

        Rect alphaRect = new Rect(cachedAlphaX, cachedSliderY_alpha, cachedAlphaW, SLIDER_H);
        if (input.isClicked(alphaRect)) { draggingAlpha = true; applyAlphaMouse(input.mouseX); }
        if (draggingAlpha && input.mouseReleased) draggingAlpha = false;
        if (draggingAlpha) applyAlphaMouse(input.mouseX);

        hexInput.handleInput(input);
    }

    @Override
    public void onClose() {
        hexInput.onClose();
    }

    private void applyHueMouse(double mx) {
        if (cachedHueW <= 0) return;
        setHue(clamp01((float)((mx - cachedHueX) / cachedHueW)));
    }

    private void applySatMouse(double mx) {
        if (cachedSatW <= 0) return;
        setSaturation(clamp01((float)((mx - cachedSatX) / cachedSatW)));
    }

    private void applyAlphaMouse(double mx) {
        if (cachedAlphaW <= 0) return;
        setAlpha(clamp01((float)((mx - cachedAlphaX) / cachedAlphaW)));
    }

    private static void drawHueBar(CKRenderer r, Rect bar) {
        int[] stops = new int[7];
        for (int i = 0; i <= 6; i++) {
            stops[i] = hsvToArgb(i / 6f, 1f, 1f, 1f);
        }

        int totalPx = (int) bar.w();
        float segW  = bar.w() / 6f;

        for (int px = 0; px < totalPx; px++) {
            float t     = (float) px / Math.max(1f, totalPx - 1f);
            float seg   = t * 6f;
            int   segI  = Math.min(5, (int) seg);
            float segT  = seg - segI;
            int   col   = CKColor.lerp(stops[segI], stops[segI + 1], segT);
            r.rect(new Rect(bar.x() + px, bar.y(), 1, bar.h()), col);
        }

        r.roundRect(bar, RADIUS, CKColor.withAlpha(CKColor.CK_BORDER, 100));
    }

    private static void drawColorSlider(CKRenderer r,
                                        float bx, float by, float bw, float bh,
                                        int colorLeft, int colorRight,
                                        float displayValue, float logicalValue,
                                        float hoverT) {
        float trackY = by + (bh - TRACK_H) / 2f;
        int   totalPx = (int) bw;

        for (int px = 0; px < totalPx; px++) {
            float t   = totalPx <= 1 ? 0f : (float) px / (totalPx - 1f);
            int   col = CKColor.lerp(colorLeft, colorRight, t);
            r.rect(new Rect(bx + px, trackY, 1, TRACK_H), col);
        }

        r.roundRect(new Rect(bx, trackY, bw, TRACK_H), RADIUS,
                CKColor.withAlpha(CKColor.CK_BORDER, 80));

        float tr       = THUMB_R * (1f + hoverT * 0.2f);
        float thumbX   = bx + displayValue * bw;
        float thumbY   = by + bh / 2f;
        int   thumbCol = CKColor.lerp(colorLeft, colorRight, logicalValue);

        r.roundRect(new Rect(thumbX - tr - 1.5f, thumbY - tr - 1.5f,
                (tr + 1.5f) * 2f, (tr + 1.5f) * 2f), tr + 1.5f, CKColor.WHITE);
        r.roundRect(new Rect(thumbX - tr, thumbY - tr, tr * 2f, tr * 2f), tr, thumbCol);
    }

    private static void drawCheckerboard(CKRenderer r, Rect area, float rad) {
        int light = CKColor.of(255, 180, 180, 180);
        int dark  = CKColor.of(255, 120, 120, 120);
        int cellW = (int) (area.h());
        int cols  = (int) Math.ceil(area.w() / cellW);
        for (int c = 0; c < cols; c++) {
            float cx = area.x() + c * cellW;
            float cw = Math.min(cellW, area.x2() - cx);
            r.rect(new Rect(cx, area.y(), cw, area.h()), (c % 2 == 0) ? light : dark);
        }
    }

    private static int hsvToArgb(float h, float s, float v, float a) {
        float r, g, b;
        if (s <= 0f) {
            r = g = b = v;
        } else {
            float hh = (h % 1f) * 6f;
            int   i  = (int) hh;
            float ff = hh - i;
            float p  = v * (1f - s);
            float q  = v * (1f - s * ff);
            float t2 = v * (1f - s * (1f - ff));
            switch (i) {
                case 0  -> { r = v;  g = t2; b = p;  }
                case 1  -> { r = q;  g = v;  b = p;  }
                case 2  -> { r = p;  g = v;  b = t2; }
                case 3  -> { r = p;  g = q;  b = v;  }
                case 4  -> { r = t2; g = p;  b = v;  }
                default -> { r = v;  g = p;  b = q;  }
            }
        }
        return CKColor.of(
                Math.round(a * 255f),
                Math.round(r * 255f),
                Math.round(g * 255f),
                Math.round(b * 255f)
        );
    }

    private static float[] rgbToHsv(float r, float g, float b) {
        float max = Math.max(r, Math.max(g, b));
        float min = Math.min(r, Math.min(g, b));
        float d   = max - min;
        float h, s, v;
        v = max;
        s = max == 0f ? 0f : d / max;
        if (d == 0f) {
            h = 0f;
        } else if (max == r) {
            h = (g - b) / d;
            if (g < b) h += 6f;
            h /= 6f;
        } else if (max == g) {
            h = ((b - r) / d + 2f) / 6f;
        } else {
            h = ((r - g) / d + 4f) / 6f;
        }
        return new float[]{ h, s, v };
    }

    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }
}