package com.ckittya.widgets;

import com.ckittya.anim.CKAnimation;
import com.ckittya.input.CKInputContext;
import com.ckittya.layout.CKLayout;
import com.ckittya.render.CKRenderer;
import com.ckittya.style.CKStyles;
import com.ckittya.util.CKColor;
import com.ckittya.util.Rect;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class CKSelectionStrip extends CKWidget {

    private final List<CKWidget> children = new ArrayList<>();
    private final CKLayout.ContainerConfig containerCfg = new CKLayout.ContainerConfig();

    private int selectedIndex = -1;
    private int pendingSelectedIndex = -1;
    private int hoveredIndex = -1;
    private Rect indicator = Rect.ZERO;
    private Rect targetIndicator = Rect.ZERO;

    private boolean clip = true;
    private float radius = CKStyles.theme().selectionRadius;
    private float indicatorSpeed = CKStyles.theme().selectionSpeed;

    private int indicatorColor = CKStyles.theme().selectionIndicator;
    private int indicatorBorder = CKStyles.theme().selectionBorder;

    private Consumer<Integer> onSelect = null;

    public CKSelectionStrip container(java.util.function.Consumer<CKLayout.ContainerConfig> fn) {
        fn.accept(containerCfg);
        return this;
    }

    public CKSelectionStrip clip(boolean clip) {
        this.clip = clip;
        return this;
    }

    public CKSelectionStrip radius(float radius) {
        this.radius = radius;
        return this;
    }

    public CKSelectionStrip indicatorColor(int color) {
        this.indicatorColor = color;
        return this;
    }

    public CKSelectionStrip indicatorBorder(int color) {
        this.indicatorBorder = color;
        return this;
    }

    public CKSelectionStrip indicatorSpeed(float speed) {
        this.indicatorSpeed = speed;
        return this;
    }

    public CKSelectionStrip onSelect(Consumer<Integer> onSelect) {
        this.onSelect = onSelect;
        return this;
    }

    public CKSelectionStrip add(CKWidget widget) {
        children.add(widget);
        return this;
    }

    public CKSelectionStrip remove(CKWidget widget) {
        children.remove(widget);
        if (selectedIndex >= children.size()) {
            selectedIndex = children.isEmpty() ? -1 : children.size() - 1;
        }
        return this;
    }

    public List<CKWidget> children() {
        return children;
    }

    public int selectedIndex() {
        return selectedIndex;
    }

    public CKSelectionStrip selectedIndex(int index) {
        pendingSelectedIndex = index;
        if (!children.isEmpty()) {
            selectedIndex = Math.max(-1, Math.min(index, children.size() - 1));
        }
        return this;
    }

    public void layoutChildren() {
        if (children.isEmpty()) return;

        if (pendingSelectedIndex >= 0) {
            selectedIndex = Math.max(-1, Math.min(pendingSelectedIndex, children.size() - 1));
        }

        boolean isRow = containerCfg.axis == CKLayout.Axis.ROW;
        for (CKWidget child : children) {
            var lc = child.layoutConfig();
            if (isRow) {
                if (lc.growX == 0 && lc.prefWidth < 0) lc.growX = 1;
            } else {
                if (lc.growY == 0 && lc.prefHeight < 0) lc.growY = 1;
            }
            if (lc.alignSelf == null) lc.alignSelf = CKLayout.Align.STRETCH;
        }

        CKLayout.layout(containerCfg, getBounds(), children);
        for (CKWidget child : children) {
            if (child instanceof CKSelectionStrip strip) {
                strip.layoutChildren();
            } else if (child instanceof CKContainer container) {
                container.layoutChildren();
            }
        }
        syncIndicatorToSelection();
    }

    @Override
    public void update(CKInputContext input, float deltaTicks) {
        for (CKWidget child : children) {
            if (child.isVisible() && child.isEnabled()) {
                child.update(input, deltaTicks);
            }
        }

        if (selectedIndex < 0 && hoveredIndex >= 0) {
            targetIndicator = children.get(hoveredIndex).getBounds();
        } else if (selectedIndex >= 0 && selectedIndex < children.size()) {
            targetIndicator = children.get(selectedIndex).getBounds();
        } else {
            targetIndicator = Rect.ZERO;
        }

        indicator = CKAnimation.approach(
                indicator,
                targetIndicator,
                indicatorSpeed,
                deltaTicks
        );
    }

    @Override
    public void draw(CKRenderer r) {
        Rect b = getBounds();

        if (indicator.w() > 0 && indicator.h() > 0) {
            Rect ind = indicator.inset(-1f);
            r.roundRect(ind, radius, CKColor.withAlphaF(indicatorBorder, 0.85f));
            r.roundRect(ind.inset(1f), Math.max(0f, radius - 1f), CKColor.withAlphaF(indicatorColor, 0.55f));
        }

        if (clip) r.pushScissor(b);

        for (CKWidget child : children) {
            if (child.isVisible()) {
                child.draw(r);
            }
        }

        if (clip) r.popScissor();
    }

    @Override
    public void handleInput(CKInputContext input) {
        hoveredIndex = -1;
        if (input.mousePressed) {
            for (int i = 0; i < children.size(); i++) {
                CKWidget child = children.get(i);
                if (child.isVisible() && child.getBounds().contains(input.mouseX, input.mouseY)) {
                    hoveredIndex = i;
                    selectedIndex = i;
                    targetIndicator = child.getBounds();
                    if (onSelect != null) onSelect.accept(i);
                    break;
                }
            }
        }

        for (CKWidget child : children) {
            if (child.isVisible() && child.isEnabled()) {
                child.handleInput(input);
            }
        }
    }

    @Override
    public void onClose() {
        for (CKWidget child : children) child.onClose();
    }

    private void syncIndicatorToSelection() {
        if (selectedIndex >= 0 && selectedIndex < children.size()) {
            indicator = children.get(selectedIndex).getBounds();
            targetIndicator = indicator;
        }
    }
}