package com.ckittya.widgets;

import com.ckittya.input.CKInputContext;
import com.ckittya.render.CKRenderer;
import com.ckittya.util.CKColor;

public class CKButton extends CKWidget {

    private String   label;
    private Runnable onClick;

    private int   bgColor   = CKColor.CK_SURFACE;
    private int   bgHover   = CKColor.CK_ACCENT;
    private int   bgPress   = CKColor.CK_ACCENT_DIM;
    private int   textColor = CKColor.CK_TEXT;
    private float radius    = 6f;

    private float   hoverT   = 0f;
    private float   pressT   = 0f;
    private boolean pressing = false;

    public CKButton(String label, Runnable onClick) {
        this.label = label;
        this.onClick = onClick;

        var t = com.ckittya.style.CKStyles.theme();
        this.bgColor = t.buttonBg;
        this.bgHover = t.buttonHover;
        this.bgPress = t.buttonPress;
        this.textColor = t.buttonText;
        this.radius = t.buttonRadius;

        layoutConfig().size(80, 20);
    }

    public CKButton label(String l)     { this.label   = l; return this; }
    public CKButton onClick(Runnable r) { this.onClick = r; return this; }
    public CKButton bg(int c)          { this.bgColor = c; return this; }
    public CKButton bgHover(int c)     { this.bgHover = c; return this; }
    public CKButton bgPress(int c)     { this.bgPress = c; return this; }
    public CKButton textColor(int c)   { this.textColor = c; return this; }
    public CKButton radius(float r)    { this.radius  = r; return this; }

    @Override
    public void update(CKInputContext input, float deltaTicks) {
        boolean isHov = hovered(input);
        float dt = Math.max(0f, deltaTicks);
        var t = com.ckittya.style.CKStyles.theme();
        hoverT = com.ckittya.anim.CKAnimation.approach(hoverT, pressing ? 0f : (isHov ? 1f : 0f), t.buttonHoverSpeed, dt);
        pressT = com.ckittya.anim.CKAnimation.approach(pressT, pressing ? 1f : 0f, t.buttonPressSpeed, dt);
    }

    @Override
    public void draw(CKRenderer r) {
        int bg = CKColor.lerp(
            CKColor.lerp(bgColor, bgHover, hoverT),
            bgPress,
            pressT
        );

        r.roundRect(getBounds(), radius, bg);
        r.textCentred(label, getBounds(), textColor);
    }

    @Override
    public void handleInput(CKInputContext input) {
        if (input.isClicked(getBounds())) pressing = true;

        if (pressing && input.mouseReleased) {
            pressing = false;
            if (input.isReleased(getBounds()) && onClick != null) {
                onClick.run();
            }
        }
    }
}
