package com.ckittya.widgets;

import com.ckittya.anim.CKAnimation;
import com.ckittya.input.CKInputContext;
import com.ckittya.render.CKRenderer;
import com.ckittya.util.CKColor;
import com.ckittya.util.Rect;

import java.util.function.Consumer;
import java.util.function.Function;

public class CKSlider extends CKWidget {

    private float min, max, value;
    private String label = null;
    private Function<Float, String> formatter = v -> String.format("%.1f", v);
    private Consumer<Float> onChange = null;

    private int   trackColor  = com.ckittya.style.CKStyles.theme().sliderTrack;
    private int   fillColor   = com.ckittya.style.CKStyles.theme().sliderFill;
    private int   thumbColor  = com.ckittya.style.CKStyles.theme().sliderThumb;
    private int   textColor   = com.ckittya.style.CKStyles.theme().sliderText;
    private float trackHeight = com.ckittya.style.CKStyles.theme().sliderTrackHeight;
    private float thumbRadius = com.ckittya.style.CKStyles.theme().sliderThumbRadius;

    private static final float SNAP_SPEED = 18f;

    private boolean dragging  = false;
    private float   hoverT    = 0f;

    private float displayValue;

    private float cachedTrackX = 0f;
    private float cachedTrackW = 0f;

    public CKSlider(float min, float max, float initial) {
        this.min          = min;
        this.max          = max;
        this.value        = clamp(initial);
        this.displayValue = this.value;
        layoutConfig().fillWidth().height(20);
    }

    public CKSlider label(String l)                   { this.label = l; return this; }
    public CKSlider format(Function<Float, String> f) { this.formatter = f; return this; }
    public CKSlider onChange(Consumer<Float> c)       { this.onChange = c; return this; }
    public CKSlider trackColor(int c)                 { this.trackColor = c; return this; }
    public CKSlider fillColor(int c)                  { this.fillColor = c; return this; }
    public CKSlider thumbColor(int c)                 { this.thumbColor = c; return this; }

    public float getValue() { return value; }

    public void setValue(float v) {
        float prev = this.value;
        this.value = clamp(v);
        if (this.value != prev && onChange != null) onChange.accept(this.value);
    }

    @Override
    public void update(CKInputContext input, float deltaTicks) {
        float dt = Math.max(0f, deltaTicks);
        var t = com.ckittya.style.CKStyles.theme();

        boolean overTrack = cachedTrackW > 0
                ? new Rect(cachedTrackX, y(), cachedTrackW, h()).contains(input.mouseX, input.mouseY)
                : false;
        hoverT = CKAnimation.approach(hoverT, (dragging || overTrack) ? 1f : 0f, t.sliderHoverSpeed, dt);

        if (dragging) {
            displayValue = value;
        } else {
            displayValue = CKAnimation.approach(displayValue, value, SNAP_SPEED, dt / 20f);
            if (Math.abs(displayValue - value) < 0.0005f * (max - min)) {
                displayValue = value;
            }
        }
    }

    @Override
    public void draw(CKRenderer r) {
        float bx = x(), by = y(), bw = w(), bh = h();

        float labelW = 0f;
        if (label != null) {
            labelW = r.textWidth(label) + 8f;
            r.text(label, bx, by + (bh - r.fontHeight()) / 2f, textColor);
        }

        String valText = formatter.apply(value);
        float  valW    = r.textWidth(valText) + 8f;

        cachedTrackX = bx + labelW;
        cachedTrackW = Math.max(8f, bw - labelW - valW);
        float trackY = by + bh / 2f - trackHeight / 2f;

        r.roundRect(new Rect(cachedTrackX, trackY, cachedTrackW, trackHeight),
                    trackHeight / 2f, trackColor);

        float fillW = cachedTrackW * displayT();
        if (fillW > 0.5f) {
            r.roundRect(new Rect(cachedTrackX, trackY, fillW, trackHeight),
                        trackHeight / 2f, fillColor);
        }

        float tr = thumbRadius * (1f + hoverT * 0.22f);
        float tx = cachedTrackX + cachedTrackW * displayT();
        float ty = by + bh / 2f;
        r.roundRect(new Rect(tx - tr, ty - tr, tr * 2f, tr * 2f),
                    tr, CKColor.lerp(thumbColor, fillColor, hoverT * 0.35f));

        r.text(valText, bx + bw - r.textWidth(valText),
               by + (bh - r.fontHeight()) / 2f, CKColor.CK_TEXT_DIM);
    }

    @Override
    public void handleInput(CKInputContext input) {
        Rect trackRect = new Rect(cachedTrackX, y(), cachedTrackW, h());

        if (input.isClicked(trackRect)) {
            dragging = true;
            applyMouseX(input.mouseX);
        }

        if (dragging && input.mouseReleased) dragging = false;

        if (dragging) {
            applyMouseX(input.mouseX);
        }
    }

    private void applyMouseX(double mouseX) {
        if (cachedTrackW <= 0f) return;
        float raw = (float)((mouseX - cachedTrackX) / cachedTrackW);
        setValue(min + clamp01(raw) * (max - min));
    }

    private float t()        { return (value        - min) / (max - min); }
    private float displayT() { return (displayValue - min) / (max - min); }

    private float clamp(float v)         { return Math.max(min, Math.min(max, v)); }
    private static float clamp01(float v){ return Math.max(0f,  Math.min(1f, v)); }
}
