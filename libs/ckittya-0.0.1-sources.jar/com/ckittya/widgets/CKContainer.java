package com.ckittya.widgets;

import com.ckittya.input.CKInputContext;
import com.ckittya.layout.CKLayout;
import com.ckittya.render.CKRenderer;

import java.util.ArrayList;
import java.util.List;

public class CKContainer extends CKWidget {

    protected boolean clip = true;

    protected final CKLayout.ContainerConfig containerCfg =
            new CKLayout.ContainerConfig();

    protected final List<CKWidget> children =
            new ArrayList<>();

    public CKContainer clip(boolean c) {
        this.clip = c;
        return this;
    }

    public CKContainer container(java.util.function.Consumer<CKLayout.ContainerConfig> fn) {
        fn.accept(containerCfg);
        return this;
    }

    public CKContainer add(CKWidget widget) {
        children.add(widget);
        return this;
    }

    public CKContainer remove(CKWidget widget) {
        children.remove(widget);
        return this;
    }

    public List<CKWidget> children() {
        return children;
    }

    public void layoutChildren() {
        if (children.isEmpty()) return;

        CKLayout.layout(containerCfg, getBounds(), children);

        for (CKWidget child : children) {
            if (child instanceof CKContainer c) {
                c.layoutChildren();
            }

            if (child instanceof CKSelectionStrip s) {
                s.layoutChildren();
            }
        }
    }

    @Override
    public void update(CKInputContext input, float deltaTicks) {
        for (CKWidget child : children) {
            if (child.isVisible() && child.isEnabled()) {
                child.update(input, deltaTicks);
            }
        }
    }

    @Override
    public void draw(CKRenderer r) {
        if (clip) {
            r.pushScissor(getBounds());
        }

        for (CKWidget child : children) {
            if (child.isVisible()) {
                child.draw(r);
            }
        }

        if (clip) {
            r.popScissor();
        }
    }

    @Override
    public void handleInput(CKInputContext input) {
        for (CKWidget child : children) {
            if (child.isVisible() && child.isEnabled()) {
                child.handleInput(input);
            }
        }
    }

    @Override
    public void onClose() {
        for (CKWidget child : children) {
            child.onClose();
        }
    }
}