package com.ckittya.widgets;

import com.ckittya.layout.CKLayout;
import com.ckittya.render.CKRenderer;
import com.ckittya.style.CKStyles;
import com.ckittya.util.CKColor;
import com.ckittya.util.Rect;

public class CKPanel extends CKContainer {

    private int bgColor =
            CKStyles.theme().panelBg;

    private int borderColor =
            CKStyles.theme().panelBorder;

    private float radius =
            CKStyles.theme().panelRadius;

    public CKPanel background(int color) {
        this.bgColor = color;
        return this;
    }

    public CKPanel border(int color) {
        this.borderColor = color;
        return this;
    }

    public CKPanel radius(float radius) {
        this.radius = radius;
        return this;
    }

    @Override
    public CKPanel clip(boolean c) {
        super.clip(c);
        return this;
    }

    @Override
    public CKPanel container(java.util.function.Consumer<CKLayout.ContainerConfig> fn) {
        super.container(fn);
        return this;
    }

    @Override
    public CKPanel add(CKWidget widget) {
        super.add(widget);
        return this;
    }

    @Override
    public CKPanel remove(CKWidget widget) {
        super.remove(widget);
        return this;
    }

    @Override
    public void draw(CKRenderer r) {
        Rect b = getBounds();

        if (CKColor.alpha(bgColor) > 0) {
            r.roundRect(b, radius, bgColor);
        }

        if (CKColor.alpha(borderColor) > 0) {
            r.roundRect(b, radius, borderColor);

            r.roundRect(
                    b.inset(1f),
                    Math.max(0f, radius - 1f),
                    bgColor
            );
        }

        super.draw(r);
    }
}