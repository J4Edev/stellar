package com.ckittya.anim;

import com.ckittya.input.CKInputContext;

public interface CKAnimatable {
    void update(CKInputContext input, float deltaTicks);
}
