package com.ckittya.anim;

import com.ckittya.util.Rect;

public final class CKAnimation {

    private CKAnimation() {}

    public static float clamp01(float t) {
        return Math.max(0f, Math.min(1f, t));
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * clamp01(t);
    }

    public static int lerp(int a, int b, float t) {
        return Math.round(lerp(a, b, t));
    }

    public static Rect lerp(Rect from, Rect to, float t) {
        return new Rect(
            lerp(from.x(), to.x(), t),
            lerp(from.y(), to.y(), t),
            lerp(from.w(), to.w(), t),
            lerp(from.h(), to.h(), t)
        );
    }

    public static float approach(float current, float target, float speed, float deltaSeconds) {
        if (speed <= 0f || deltaSeconds <= 0f) return target;
        float t = 1f - (float)Math.exp(-speed * deltaSeconds);
        return current + (target - current) * t;
    }

    public static Rect approach(Rect current, Rect target, float speed, float deltaSeconds) {
        return new Rect(
            approach(current.x(), target.x(), speed, deltaSeconds),
            approach(current.y(), target.y(), speed, deltaSeconds),
            approach(current.w(), target.w(), speed, deltaSeconds),
            approach(current.h(), target.h(), speed, deltaSeconds)
        );
    }

    public static float smoothStep(float t) {
        t = clamp01(t);
        return t * t * (3f - 2f * t);
    }
}
