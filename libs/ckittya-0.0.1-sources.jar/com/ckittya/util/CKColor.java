package com.ckittya.util;

public final class CKColor {

    private CKColor() {}

    public static int of(int r, int g, int b) {
        return of(255, r, g, b);
    }

    public static int of(int a, int r, int g, int b) {
        return ((a & 0xFF) << 24) | ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF);
    }

    public static int hex(int hex) {
        if ((hex & 0xFF000000) == 0 && hex != 0) return hex | 0xFF000000;
        return hex;
    }

    public static int withAlpha(int color, int a) {
        return (color & 0x00FFFFFF) | ((a & 0xFF) << 24);
    }

    public static int withAlphaF(int color, float a) {
        return withAlpha(color, (int)(a * 255));
    }

    public static int   alpha(int color) { return (color >> 24) & 0xFF; }
    public static int   red  (int color) { return (color >> 16) & 0xFF; }
    public static int   green(int color) { return (color >>  8) & 0xFF; }
    public static int   blue (int color) { return  color        & 0xFF; }

    public static float alphaF(int color) { return alpha(color) / 255f; }
    public static float redF  (int color) { return red  (color) / 255f; }
    public static float greenF(int color) { return green(color) / 255f; }
    public static float blueF (int color) { return blue (color) / 255f; }

    public static int lerp(int a, int b, float t) {
        float it = 1f - t;
        return of(
            (int)(alpha(a) * it + alpha(b) * t),
            (int)(red  (a) * it + red  (b) * t),
            (int)(green(a) * it + green(b) * t),
            (int)(blue (a) * it + blue (b) * t)
        );
    }

    public static final int WHITE       = 0xFFFFFFFF;
    public static final int BLACK       = 0xFF000000;
    public static final int TRANSPARENT = 0x00000000;

    public static final int CK_BG          = of(230,  16,  12,  22);
    public static final int CK_SURFACE     = of(255,  26,  22,  40);
    public static final int CK_SURFACE_HIGH = of(255, 36,  30,  56);
    public static final int CK_BORDER      = of(160,  90,  70, 140);
    public static final int CK_ACCENT      = of(255, 130,  80, 230);
    public static final int CK_HOVER       = of(60,  130,  80, 230);
    public static final int CK_ACCENT_DIM  = of(120, 110,  60, 200);
    public static final int CK_TEXT        = of(255, 225, 220, 235);
    public static final int CK_TEXT_DIM    = of(160, 175, 170, 190);
    public static final int CK_DANGER      = of(255, 180,  55,  55);
}
