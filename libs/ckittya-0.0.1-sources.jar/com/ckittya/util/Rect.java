package com.ckittya.util;

public record Rect(float x, float y, float w, float h) {

    public static final Rect ZERO = new Rect(0, 0, 0, 0);

    public float x2() { return x + w; }
    public float y2() { return y + h; }

    public boolean contains(double px, double py) {
        return px >= x && px <= x2() && py >= y && py <= y2();
    }

    public Rect translate(float dx, float dy) {
        return new Rect(x + dx, y + dy, w, h);
    }

    public Rect inset(float amount) {
        return new Rect(x + amount, y + amount, w - amount * 2, h - amount * 2);
    }

    public Rect withSize(float nw, float nh) {
        return new Rect(x, y, nw, nh);
    }

    public Rect withPos(float nx, float ny) {
        return new Rect(nx, ny, w, h);
    }

    public Rect clampTo(Rect parent) {
        float cx = Math.max(x, parent.x);
        float cy = Math.max(y, parent.y);
        float cx2 = Math.min(x2(), parent.x2());
        float cy2 = Math.min(y2(), parent.y2());
        return new Rect(cx, cy, Math.max(0, cx2 - cx), Math.max(0, cy2 - cy));
    }
}
