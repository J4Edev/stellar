package com.ckittya.core;

import com.ckittya.input.CKInputContext;
import com.ckittya.render.CKRenderer;
import com.ckittya.style.CKStyles;
import com.ckittya.util.Rect;
import com.ckittya.widgets.CKContainer;
import com.ckittya.widgets.CKWidget;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public abstract class CKScreen extends Screen {

    private final List<CKWidget> roots    = new ArrayList<>();
    private final CKInputContext input    = new CKInputContext();
    private final CKRenderer     renderer = CKRenderer.get();

    private String pendingTooltip = null;
    private double tooltipX, tooltipY;

    protected CKScreen(String title) {
        super(Component.literal(title));
    }

    protected abstract void build();

    protected void addRoot(CKWidget widget) {
        roots.add(widget);
    }

    protected void clearRoots() {
        roots.forEach(CKWidget::onClose);
        roots.clear();
    }

    protected int screenWidth()  { return width; }
    protected int screenHeight() { return height; }

    @Override
    protected void init() {
        clearRoots();
        build();
        runLayoutPass();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY, float deltaTicks) {
        super.extractRenderState(context, mouseX, mouseY, deltaTicks);

        input.mouseX = mouseX;
        input.mouseY = mouseY;

        renderer.begin(context, width, height);

        int bg = CKStyles.theme().screenBg;
        if ((bg >>> 24) != 0) {
            renderer.rect(new Rect(0, 0, width, height), bg);
        }

        for (CKWidget root : roots) {
            if (root.isVisible() && root.isEnabled()) {
                root.update(input, deltaTicks);
            }
        }

        pendingTooltip = null;
        for (CKWidget root : roots) {
            if (root.isVisible()) {
                root.draw(renderer);
                collectTooltip(root, mouseX, mouseY);
            }
        }

        if (pendingTooltip != null) {
            drawTooltip(renderer, pendingTooltip, (float) tooltipX, (float) tooltipY);
        }

        renderer.end();

        for (CKWidget root : roots) {
            if (root.isVisible() && root.isEnabled()) {
                root.handleInput(input);
            }
        }

        input.resetFrameEvents();
    }

    @Override
    public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent event, boolean doubleClick) {
        input.mouseX = event.x();
        input.mouseY = event.y();
        if (event.button() == GLFW.GLFW_MOUSE_BUTTON_LEFT)  input.mousePressed = true;
        if (event.button() == GLFW.GLFW_MOUSE_BUTTON_RIGHT) input.rightPressed = true;
        input.mouseDown = true;
        return true;
    }

    @Override
    public boolean mouseReleased(net.minecraft.client.input.MouseButtonEvent event) {
        input.mouseX = event.x();
        input.mouseY = event.y();
        if (event.button() == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            input.mouseReleased = true;
            input.mouseDown     = false;
        }
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double hScroll, double vScroll) {
        input.scrollDelta = vScroll;
        return true;
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent event) {
        input.keyPressed = event.key();
        input.keyMods    = event.modifiers();
        super.keyPressed(event);
        return true;
    }

    @Override
    public boolean charTyped(net.minecraft.client.input.CharacterEvent event) {
        char chr = (char) event.codepoint();
        if (Character.isValidCodePoint(event.codepoint()) && !Character.isISOControl(event.codepoint())) {
            input.charTyped = chr;
        }
        return true;
    }

    @Override
    public void onClose() {
        roots.forEach(CKWidget::onClose);
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void resize(int width, int height) {
        super.resize(width, height);
        clearRoots();
        build();
        runLayoutPass();
    }

    private void runLayoutPass() {
        for (CKWidget root : roots) {
            if (root.getBounds().w() <= 0 || root.getBounds().h() <= 0) {
                root.setBounds(new Rect(0, 0, width, height));
            }
        }
        for (CKWidget root : roots) {
            if (root instanceof CKContainer container) {
                container.layoutChildren();
            }
            if (root instanceof com.ckittya.widgets.CKSelectionStrip strip) {
                strip.layoutChildren();
            }
        }
    }

    private void collectTooltip(CKWidget widget, double mx, double my) {
        if (widget.getTooltip() != null && widget.getBounds().contains(mx, my)) {
            pendingTooltip = widget.getTooltip();
            tooltipX = mx;
            tooltipY = my;
        }
        if (widget instanceof CKContainer container) {
            for (CKWidget child : container.children()) {
                if (child.isVisible()) collectTooltip(child, mx, my);
            }
        }
        if (widget instanceof com.ckittya.widgets.CKSelectionStrip strip) {
            for (CKWidget child : strip.children()) {
                if (child.isVisible()) collectTooltip(child, mx, my);
            }
        }
    }

    private void drawTooltip(CKRenderer r, String tip, float mx, float my) {
        int   tw = r.textWidth(tip) + 8;
        int   th = r.fontHeight() + 6;
        float tx = Math.min(mx + 12, width  - tw - 4);
        float ty = Math.min(my + 12, height - th - 4);

        r.roundRect(new Rect(tx, ty, tw, th), 4f, com.ckittya.util.CKColor.CK_BORDER);
        r.roundRect(new Rect(tx, ty, tw, th).inset(1f), 3f, com.ckittya.util.CKColor.of(220, 20, 20, 28));
        r.text(tip, tx + 4, ty + 3, com.ckittya.util.CKColor.CK_TEXT);
    }
}
